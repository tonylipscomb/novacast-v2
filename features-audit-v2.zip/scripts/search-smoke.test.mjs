import assert from 'node:assert/strict';
import test from 'node:test';

import {
  SEARCH_MIN_QUERY_LENGTH,
  resolveSearchNotificationForStatus,
  searchHitKey,
  searchHitKindLabel,
} from '../src/features/search/searchScreenLogic.ts';

test('Search notifications only surface recoverable errors', () => {
  assert.equal(resolveSearchNotificationForStatus('idle', false), null);
  assert.equal(resolveSearchNotificationForStatus('ready', false), null);
  assert.equal(resolveSearchNotificationForStatus('empty', false), null);
  assert.equal(resolveSearchNotificationForStatus('loading', false), null);

  const error = resolveSearchNotificationForStatus('error', false);
  assert.equal(error?.title, 'Search unavailable');
  assert.match(error?.message ?? '', /could not search/i);
  assert.equal(resolveSearchNotificationForStatus('error', true)?.persistent, true);
});

test('Search helpers format result metadata consistently', () => {
  assert.equal(SEARCH_MIN_QUERY_LENGTH, 2);
  assert.equal(searchHitKindLabel('movie'), 'Movie');
  assert.equal(searchHitKindLabel('series'), 'Series');
  assert.equal(searchHitKindLabel('live'), 'Live TV');
  assert.equal(searchHitKey({ kind: 'movie', id: '42', title: 'Action Movie' }), 'movie:42');
});
