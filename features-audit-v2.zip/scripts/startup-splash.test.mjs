import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

import {
  canExitStartupSplash,
  getStartupSplashRemainingMs,
  NOVACAST_MIN_SPLASH_DURATION_MS,
} from '../src/features/startup/startupLogic.ts';

const launchSource = readFileSync(new URL('../src/features/startup/NovaCastLaunchSequence.tsx', import.meta.url), 'utf8');
const layoutSource = readFileSync(new URL('../src/app/_layout.tsx', import.meta.url), 'utf8');

test('branded startup holds for at least 5.5 seconds', () => {
  assert.equal(NOVACAST_MIN_SPLASH_DURATION_MS, 5500);
  assert.equal(getStartupSplashRemainingMs(1000, 1000), 5500);
  assert.equal(getStartupSplashRemainingMs(1000, 4200), 2300);
  assert.equal(getStartupSplashRemainingMs(1000, 7000), 0);
});

test('splash waits for readiness and minimum duration', () => {
  assert.equal(canExitStartupSplash(false, 1000, 7000), false);
  assert.equal(canExitStartupSplash(true, 1000, 4200), false);
  assert.equal(canExitStartupSplash(true, 1000, 6500), true);
});

test('launch uses one artwork and a compact status panel', () => {
  assert.equal(launchSource.includes('novacastnewcard'), false);
  assert.equal((launchSource.match(/<Image /g) ?? []).length, 1);

  const statusStyles = launchSource.slice(launchSource.indexOf('statusBlock:'), launchSource.indexOf('statusRule:'));
  assert.match(statusStyles, /width: '90%'/);
  assert.match(statusStyles, /maxWidth: 420/);
  assert.doesNotMatch(statusStyles, /left: 0|right: 0/);
});

test('native splash handoff is driven by the branded launch layout', () => {
  assert.match(layoutSource, /const handleLaunchLayout/);
  assert.match(layoutSource, /handleLaunchLayout[\s\S]*hideAsync/);
  assert.match(layoutSource, /onLayout=\{handleLaunchLayout\}/);
  const readinessEffect = layoutSource.slice(layoutSource.indexOf('useEffect(() => {'), layoutSource.indexOf('const handleLaunchLayout'));
  assert.doesNotMatch(readinessEffect, /hideAsync/);
});
