import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect, useRef, useState } from 'react';
import { LogBox, StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AppNotificationProvider } from '@/features/notifications/AppNotificationProvider';
import { NovaCastLaunchSequence } from '@/features/startup/NovaCastLaunchSequence';
import { getStartupSplashRemainingMs } from '@/features/startup/startupLogic';
import { isStartupReady, subscribeStartupReadiness } from '@/features/startup/startupReadiness';

SplashScreen.preventAutoHideAsync().catch(() => {
  // Fast refresh can call this more than once.
});

export default function RootLayout() {
  const [showBrandSplash, setShowBrandSplash] = useState(true);
  const [exitRequested, setExitRequested] = useState(false);
  const splashHiddenRef = useRef(false);
  const exitRequestedRef = useRef(false);
  const [startedAt] = useState(() => Date.now());

  useEffect(() => {
    if (__DEV__) {
      LogBox.ignoreLogs(['Open debugger to view warnings']);
    }
  }, []);

  useEffect(() => {
    let exitTimer: ReturnType<typeof setTimeout> | undefined;

    const requestExit = () => {
      if (exitRequestedRef.current) return;

      exitRequestedRef.current = true;
      setExitRequested(true);
    };

    const scheduleExit = () => {
      if (exitTimer || exitRequestedRef.current) return;

      exitTimer = setTimeout(requestExit, getStartupSplashRemainingMs(startedAt));
    };

    const unsubscribe = subscribeStartupReadiness(() => {
      scheduleExit();
    });

    if (isStartupReady()) {
      scheduleExit();
    }

    return () => {
      unsubscribe();
      if (exitTimer) clearTimeout(exitTimer);
    };
  }, [startedAt]);

  const handleLaunchLayout = () => {
    if (splashHiddenRef.current) return;

    splashHiddenRef.current = true;
    // The native splash stays up until the branded React launch screen has laid out.
    void SplashScreen.hideAsync().catch(() => {});
  };

  const handleLaunchExitComplete = () => {
    setShowBrandSplash(false);
  };

  return (
    <SafeAreaProvider>
      <View style={styles.root}>
        <Stack
          screenOptions={{
            headerShown: false,
            animation: 'fade',
            contentStyle: styles.routeContent,
          }}
        />

        <AppNotificationProvider />

        {showBrandSplash ? (
          <View pointerEvents="none" style={styles.brandSplash}>
            <NovaCastLaunchSequence
              exitRequested={exitRequested}
              onExitComplete={handleLaunchExitComplete}
              onLayout={handleLaunchLayout}
            />
          </View>
        ) : null}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#000000',
  },
  routeContent: {
    backgroundColor: '#07090D',
  },
  brandSplash: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    zIndex: 999,
    backgroundColor: '#000000',
  },
});
