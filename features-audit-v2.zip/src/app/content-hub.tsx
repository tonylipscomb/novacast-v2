import { ContentHubOverlayScreen } from '@/features/hub/ContentHubOverlayScreen';

export default function ContentHubRoute() {
  return <ContentHubOverlayScreen />;
}
