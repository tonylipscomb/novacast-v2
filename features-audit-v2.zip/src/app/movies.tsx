import { useProviderStore } from '@/features/providers/providerStore';
import { MoviesScreen } from '@/features/movies/MoviesScreen';

export default function MoviesRoute() {
  const { providerGeneration, selectedProvider } = useProviderStore();
  const providerKey = `${selectedProvider?.id ?? 'demo-provider'}:${providerGeneration}`;

  return <MoviesScreen key={providerKey} />;
}
