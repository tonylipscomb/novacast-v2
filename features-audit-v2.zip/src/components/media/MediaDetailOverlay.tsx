import type { ComponentProps, ComponentType, ElementRef, ReactNode, RefObject } from 'react';
import { useEffect, useRef, useState } from 'react';
import * as ReactNative from 'react-native';
import {
  Animated,
  Easing,
  findNodeHandle,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { TvRemoteImage } from '@/components/media/TvRemoteImage';
import { MediaArtworkFallback } from '@/features/media-browser/MediaArtworkFallback';
import type { MediaCastMember, MediaDetail, MediaDetailEpisode } from '@/features/media-browser/mediaTypes';
import { displayStreamTitle } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

type MediaDetailOverlayProps = {
  visible: boolean;
  blurTarget?: RefObject<View | null>;
  detail: MediaDetail | null;
  detailLoading?: boolean;
  detailError?: string | null;
  continueWatchingLabel?: string;
  isFavorite?: boolean;
  isWatchlisted?: boolean;
  selectedSeasonNumber?: number;
  focusedEpisodeId?: string | null;
  onClose: () => void;
  onRetry?: () => void;
  onPlay?: () => void;
  onPlayFromBeginning?: () => void;
  onTrailerPress?: () => void;
  onFavoritePress?: () => void;
  onWatchlistPress?: () => void;
  onSeasonPress?: (seasonNumber: number) => void;
  onEpisodePress?: (episode: MediaDetailEpisode) => void;
  onEpisodeFocus?: (episodeId: string) => void;
};

type ActionId = 'play' | 'restart' | 'trailer' | 'favorite' | 'watchlist' | 'retry';

function formatDate(value?: string) {
  if (!value?.trim()) {
    return undefined;
  }

  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? new Date(parsed).toLocaleDateString() : value;
}

function formatRating(value?: number) {
  return value && value > 0 ? value.toFixed(1) : undefined;
}

function initials(value: string) {
  return value
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');
}

function handleFor(ref: { current: ElementRef<typeof Pressable> | null } | undefined) {
  return ref?.current ? findNodeHandle(ref.current) ?? undefined : undefined;
}

function OverlayAction({
  id,
  label,
  icon,
  onPress,
  primary = false,
  selected = false,
  disabled = false,
  preferred = false,
  compact = false,
  buttonRef,
  nextFocusLeft,
  nextFocusRight,
  nextFocusUp,
  nextFocusDown,
  onFocus,
  onBlur,
}: {
  id: ActionId;
  label: string;
  icon: ComponentProps<typeof MaterialCommunityIcons>['name'];
  onPress?: () => void;
  primary?: boolean;
  selected?: boolean;
  disabled?: boolean;
  preferred?: boolean;
  compact?: boolean;
  buttonRef?: (instance: ElementRef<typeof Pressable> | null) => void;
  nextFocusLeft?: number;
  nextFocusRight?: number;
  nextFocusUp?: number;
  nextFocusDown?: number;
  onFocus: (id: ActionId) => void;
  onBlur: () => void;
}) {
  const focusable = Boolean(onPress) && !disabled;

  return (
    <Pressable
      ref={buttonRef}
      focusable={focusable}
      disabled={!focusable}
      hasTVPreferredFocus={preferred && focusable}
      accessibilityLabel={label}
      {...(nextFocusLeft ? { nextFocusLeft } : {})}
      {...(nextFocusRight ? { nextFocusRight } : {})}
      {...(nextFocusUp ? { nextFocusUp } : {})}
      {...(nextFocusDown ? { nextFocusDown } : {})}
      onFocus={() => onFocus(id)}
      onBlur={onBlur}
      onPress={onPress}
      style={[
        styles.action,
        primary && styles.actionPrimary,
        compact && styles.actionMovie,
        disabled && styles.actionDisabled,
        selected && styles.actionFocused,
      ]}>
      <MaterialCommunityIcons name={icon} size={20} color={primary ? '#FFFFFF' : novaTheme.colors.textPrimary} />
      <Text style={[styles.actionLabel, primary && styles.actionLabelPrimary, disabled && styles.actionLabelDisabled]}>
        {label}
      </Text>
    </Pressable>
  );
}

function CastRow({ cast, focusedId, onFocus }: { cast: MediaCastMember[]; focusedId: string | null; onFocus: (id: string) => void }) {
  if (!cast.length) {
    return null;
  }

  return (
    <View style={styles.sectionBlock}>
      <Text style={styles.sectionLabel}>Cast</Text>
        <ScrollView focusable={false} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.castRow}>
        {cast.slice(0, 8).map((member) => {
          const focused = focusedId === member.name;
          return (
            <Pressable
              key={`${member.name}-${member.character ?? ''}`}
              focusable
              accessibilityLabel={member.name}
              onFocus={() => onFocus(member.name)}
              style={[styles.castMember, focused && styles.castMemberFocused]}>
              <View style={styles.castAvatar}>
                {member.imageUrl ? (
                  <TvRemoteImage uri={member.imageUrl} resizeMode="cover" style={styles.castImage} />
                ) : (
                  <Text style={styles.castInitials}>{initials(member.name)}</Text>
                )}
              </View>
              <Text numberOfLines={1} style={styles.castName}>{member.name}</Text>
              {member.character ? <Text numberOfLines={1} style={styles.castCharacter}>{member.character}</Text> : null}
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

function SeriesEpisodePanel({
  detail,
  selectedSeasonNumber,
  focusedEpisodeId,
  onSeasonPress,
  onEpisodePress,
  onEpisodeFocus,
}: {
  detail: MediaDetail;
  selectedSeasonNumber?: number;
  focusedEpisodeId?: string | null;
  onSeasonPress?: (seasonNumber: number) => void;
  onEpisodePress?: (episode: MediaDetailEpisode) => void;
  onEpisodeFocus?: (episodeId: string) => void;
}) {
  const selected = selectedSeasonNumber ?? detail.seasons[0]?.seasonNumber;
  const episodes = detail.episodes.filter((episode) => episode.seasonNumber === selected);

  return (
    <View style={styles.sidePanelContent}>
      <Text style={styles.sideTitle}>Seasons &amp; Episodes</Text>
      <ScrollView focusable={false} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.seasonRow}>
        {detail.seasons.map((season) => {
          const seasonFocused = focusedEpisodeId === `season-${season.seasonNumber}`;
          return (
            <Pressable
              key={season.seasonNumber}
              focusable
              accessibilityLabel={season.name ?? `Season ${season.seasonNumber}`}
              onFocus={() => onEpisodeFocus?.(`season-${season.seasonNumber}`)}
              onPress={() => onSeasonPress?.(season.seasonNumber)}
              style={[styles.seasonChip, season.seasonNumber === selected && styles.seasonChipSelected, seasonFocused && styles.seasonChipFocused]}>
              <Text style={styles.seasonText}>{season.name ?? `Season ${season.seasonNumber}`}</Text>
              <Text style={styles.seasonCount}>{season.episodeCount}</Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <ScrollView focusable={false} style={styles.episodeScroll} contentContainerStyle={styles.episodeList} showsVerticalScrollIndicator={false}>
        {episodes.length ? episodes.map((episode, index) => {
          const focused = focusedEpisodeId === episode.id;
          return (
            <Pressable
              key={episode.id}
              focusable
              accessibilityLabel={`Episode ${episode.episodeNumber}, ${episode.title}`}
              onFocus={() => onEpisodeFocus?.(episode.id)}
              onPress={() => onEpisodePress?.(episode)}
              style={[styles.episodeRow, focused && styles.episodeRowFocused]}>
              <View style={styles.episodeNumberBox}>
                <Text style={styles.episodeNumber}>{episode.episodeNumber}</Text>
              </View>
              <View style={styles.episodeCopy}>
                <Text numberOfLines={1} style={styles.episodeTitle}>{displayStreamTitle(episode.title)}</Text>
                <Text style={styles.episodeMeta}>{[episode.runtime, episode.airDate].filter(Boolean).join('  /  ') || 'Runtime unavailable'}</Text>
              </View>
              <MaterialCommunityIcons name="play-circle-outline" size={24} color={novaTheme.colors.accentHover} />
            </Pressable>
          );
        }) : (
          <Text style={styles.mutedCopy}>Episodes are not available for this season.</Text>
        )}
      </ScrollView>
    </View>
  );
}

export function MediaDetailOverlay({
  visible,
  blurTarget,
  detail,
  detailLoading = false,
  detailError,
  continueWatchingLabel,
  isFavorite = false,
  isWatchlisted = false,
  selectedSeasonNumber,
  focusedEpisodeId,
  onClose,
  onRetry,
  onPlay,
  onPlayFromBeginning,
  onTrailerPress,
  onFavoritePress,
  onWatchlistPress,
  onSeasonPress,
  onEpisodePress,
  onEpisodeFocus,
}: MediaDetailOverlayProps) {
  const { width, height } = useWindowDimensions();
  const [focusedTarget, setFocusedTarget] = useState<ActionId | string | null>(null);
  const [posterFailed, setPosterFailed] = useState(false);
  const [opacity] = useState(() => new Animated.Value(0));
  const [scale] = useState(() => new Animated.Value(0.96));
  const actionRefs = useRef(new Map<ActionId, ElementRef<typeof Pressable>>());
  const playRef = useRef<ElementRef<typeof Pressable> | null>(null);
  const [actionHandles, setActionHandles] = useState<Record<string, number>>({});
  const focusRetryCancelRef = useRef<(() => void) | null>(null);

  const firstAction: ActionId | null = onPlay
    ? 'play'
    : onPlayFromBeginning
      ? 'restart'
      : onTrailerPress
        ? 'trailer'
        : onFavoritePress
          ? 'favorite'
          : onWatchlistPress
            ? 'watchlist'
            : onRetry
              ? 'retry'
              : null;
  const actionIds = [
    onPlay ? 'play' : null,
    onPlayFromBeginning ? 'restart' : null,
    onTrailerPress ? 'trailer' : null,
    onFavoritePress ? 'favorite' : null,
    onWatchlistPress ? 'watchlist' : null,
  ].filter((item): item is ActionId => Boolean(item));
  const actionGraphKey = actionIds.join('|');

  const handleActionFocus = (id: ActionId) => {
    focusRetryCancelRef.current?.();
    focusRetryCancelRef.current = null;
    setFocusedTarget(id);
  };

  useEffect(() => {
    if (!visible) {
      return;
    }

    opacity.setValue(0);
    scale.setValue(0.96);
    const animation = Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 170, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 190, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]);
    animation.start();

    if (!firstAction) {
      return () => animation.stop();
    }

    let cancelled = false;
    let frame: number | null = null;
    let frameCount = 0;
    const stopFocusRetry = () => {
      cancelled = true;
      if (frame !== null) {
        cancelAnimationFrame(frame);
      }
      if (focusRetryCancelRef.current === stopFocusRetry) {
        focusRetryCancelRef.current = null;
      }
    };
    const requestActionFocus = () => {
      if (cancelled) {
        return;
      }

      const target = playRef.current ?? actionRefs.current.get(firstAction);
      target?.focus();
      frameCount += 1;
      if (frameCount < 8) {
        frame = requestAnimationFrame(requestActionFocus);
      } else {
        stopFocusRetry();
      }
    };

    focusRetryCancelRef.current?.();
    focusRetryCancelRef.current = stopFocusRetry;
    frame = requestAnimationFrame(requestActionFocus);

    return () => {
      animation.stop();
      stopFocusRetry();
    };
  }, [actionGraphKey, firstAction, opacity, scale, visible]);

  useEffect(() => {
    if (!visible) {
      return;
    }

    const frame = requestAnimationFrame(() => {
      const nextHandles: Record<string, number> = {};
      const graphIds = actionGraphKey ? actionGraphKey.split('|') as ActionId[] : [];
      graphIds.forEach((id) => {
        const handle = handleFor({ current: actionRefs.current.get(id) ?? null });
        if (handle) {
          nextHandles[id] = handle;
        }
      });
      setActionHandles(nextHandles);
    });

    return () => cancelAnimationFrame(frame);
  }, [actionGraphKey, visible]);

  if (!visible || !detail) {
    return null;
  }

  const title = displayStreamTitle(detail.title) || detail.title;
  const isMovie = detail.mediaType === 'movie';
  const rating = formatRating(detail.rating);
  const displayGenres = detail.genres.filter(Boolean).slice(0, 4);
  const reactNative = ReactNative as typeof ReactNative & {
    TVFocusGuideView?: typeof View;
  };
  const FocusBoundaryView = (reactNative.TVFocusGuideView ?? View) as unknown as ComponentType<{
    children?: ReactNode;
    style?: unknown;
    autoFocus?: boolean;
    trapFocusLeft?: boolean;
    trapFocusRight?: boolean;
    trapFocusUp?: boolean;
    trapFocusDown?: boolean;
  }>;
  const metadata = [
    ['Creator', detail.creator],
    ['Network', detail.network],
    ['Release Date', formatDate(detail.releaseDate)],
    ['Audio', detail.audio],
    ['Subtitles', detail.subtitles],
  ].filter((item): item is [string, string] => Boolean(item[1]));
  const renderAction = (id: ActionId) => {
    const index = actionIds.indexOf(id);
    const left = actionIds[index - 1];
    const right = actionIds[index + 1];
    const onPress = id === 'play'
      ? onPlay
      : id === 'restart'
        ? onPlayFromBeginning
        : id === 'trailer'
          ? onTrailerPress
          : id === 'favorite'
            ? onFavoritePress
            : onWatchlistPress;
    const label = id === 'play'
      ? continueWatchingLabel ?? 'Play'
      : id === 'restart'
        ? 'Restart'
        : id === 'trailer'
          ? 'Trailer'
          : id === 'favorite'
            ? isFavorite ? 'Favorited' : 'Favorite'
            : isWatchlisted ? 'In Watchlist' : 'Watchlist';
    const icon = id === 'play'
      ? 'play'
      : id === 'restart'
        ? 'restart'
        : id === 'trailer'
          ? 'movie-outline'
          : id === 'favorite'
            ? isFavorite ? 'heart' : 'heart-outline'
            : isWatchlisted ? 'bookmark' : 'bookmark-outline';

    return (
      <OverlayAction
        key={id}
        id={id}
        label={label}
        icon={icon as ComponentProps<typeof MaterialCommunityIcons>['name']}
        onPress={onPress}
        primary={id === 'play'}
        compact={isMovie}
        preferred={id === firstAction}
        selected={focusedTarget === id}
        buttonRef={(instance) => {
          if (instance) {
            actionRefs.current.set(id, instance);
            if (id === 'play') {
              playRef.current = instance;
            }
          } else {
            actionRefs.current.delete(id);
          }
        }}
        nextFocusLeft={actionHandles[left ?? id]}
        nextFocusRight={actionHandles[right ?? id]}
        nextFocusUp={actionHandles[id]}
        nextFocusDown={actionHandles[id]}
        onFocus={handleActionFocus}
        onBlur={() => setFocusedTarget(null)}
      />
    );
  };

  return (
    <Animated.View style={[styles.backdrop, { opacity }]} pointerEvents="auto" accessibilityViewIsModal>
      {blurTarget ? (
        <BlurView
          blurTarget={blurTarget}
          blurMethod="dimezisBlurViewSdk31Plus"
          intensity={42}
          tint="dark"
          style={styles.backdropBlur}
        />
      ) : null}
      <View style={styles.backdropDim} />
      <FocusBoundaryView
        style={styles.focusBoundary}
        {...(Platform.OS === 'android'
          ? { trapFocusLeft: true, trapFocusRight: true, trapFocusUp: true, trapFocusDown: true }
          : {})}>
        <Animated.View
          style={[
            styles.modal,
            isMovie && styles.modalMovie,
            {
              width: isMovie ? Math.min(Math.max(width * 0.66, 720), 1240) : Math.min(Math.max(width * 0.84, 900), 1540),
              height: isMovie ? Math.min(Math.max(height * 0.58, 420), 620) : Math.min(Math.max(height * 0.82, 560), 820),
              transform: [{ scale }],
            },
          ]}>
        <View style={[styles.modalBody, isMovie && styles.modalBodyMovie]}>
          <View style={[styles.posterColumn, isMovie && styles.posterColumnMovie]}>
            <View style={[styles.posterFrame, isMovie && styles.posterFrameMovie]}>
              {detail.posterUrl && !posterFailed ? (
                <TvRemoteImage uri={detail.posterUrl} style={styles.posterImage} onError={() => setPosterFailed(true)} />
              ) : (
                <MediaArtworkFallback title={title} kind={detail.mediaType} subtitle={detail.year} />
              )}
              {rating ? (
                <View style={styles.posterRating}>
                  <MaterialCommunityIcons name="star" size={14} color="#F6C85F" />
                  <Text style={styles.posterRatingText}>{rating}</Text>
                </View>
              ) : null}
            </View>
            {!isMovie ? <View style={styles.posterActions}>{actionIds.map(renderAction)}</View> : null}
          </View>

          <ScrollView focusable={false} style={[styles.infoColumn, isMovie && styles.infoColumnMovie]} contentContainerStyle={[styles.infoContent, isMovie && styles.infoContentMovie]} showsVerticalScrollIndicator={false}>
            <Text numberOfLines={2} style={[styles.title, isMovie && styles.titleMovie]}>{title}</Text>
            <View style={[styles.metaRow, isMovie && styles.metaRowMovie]}>
              {detail.year ? <Text style={styles.metaChip}>{detail.year}</Text> : null}
              {detail.runtime ? <Text style={styles.metaChip}>{detail.runtime}</Text> : null}
              {isMovie && detail.releaseDate ? <Text style={styles.metaChip}>Release {formatDate(detail.releaseDate)}</Text> : null}
              {detail.contentRating ? <Text style={styles.metaChip}>{detail.contentRating}</Text> : null}
              {displayGenres.map((genre) => <Text key={genre} style={styles.metaChip}>{genre}</Text>)}
              {rating ? (
                <View style={styles.ratingChip}>
                  <MaterialCommunityIcons name="star" size={13} color="#F6C85F" />
                  <Text style={styles.ratingChipText}>{rating}/10</Text>
                </View>
              ) : null}
            </View>

            {detailLoading ? <Text style={styles.loadingText}>Updating details...</Text> : null}
            {detailError ? (
              <View style={styles.inlineError}>
                <Text style={styles.inlineErrorText}>{detailError}</Text>
                {onRetry ? (
                  <OverlayAction
                    id="retry"
                    label="Retry"
                    icon="refresh"
                    onPress={onRetry}
                    selected={focusedTarget === 'retry'}
                    onFocus={setFocusedTarget}
                    onBlur={() => setFocusedTarget(null)}
                  />
                ) : null}
              </View>
            ) : null}

            {detail.synopsis?.trim() || !isMovie ? (
              <View style={[styles.sectionBlock, isMovie && styles.sectionBlockMovie]}>
                <Text style={styles.sectionLabel}>Synopsis</Text>
                <Text numberOfLines={isMovie ? 3 : 8} style={[styles.description, isMovie && styles.descriptionMovie]}>
                  {detail.synopsis || 'No synopsis available.'}
                </Text>
              </View>
            ) : null}

            {isMovie ? <View style={styles.movieActionRow}>{actionIds.map(renderAction)}</View> : null}

            <CastRow
              cast={detail.cast}
              focusedId={typeof focusedTarget === 'string' && focusedTarget.startsWith('cast:') ? focusedTarget.slice(5) : null}
              onFocus={(id) => setFocusedTarget(`cast:${id}`)}
            />
          </ScrollView>

          {!isMovie ? (
            <View style={styles.sideColumn}>
              <SeriesEpisodePanel
                detail={detail}
                selectedSeasonNumber={selectedSeasonNumber}
                focusedEpisodeId={focusedEpisodeId}
                onSeasonPress={onSeasonPress}
                onEpisodePress={onEpisodePress}
                onEpisodeFocus={onEpisodeFocus}
              />
            </View>
          ) : null}
        </View>

        {!isMovie && metadata.length ? (
          <View style={styles.metadataRow}>
            {metadata.slice(0, 6).map(([label, value]) => (
              <View key={`${label}-${value}`} style={styles.metadataItem}>
                <Text style={styles.metadataLabel}>{label}</Text>
                <Text numberOfLines={1} style={styles.metadataValue}>{value}</Text>
              </View>
            ))}
          </View>
        ) : null}
        {!isMovie ? <View style={styles.footer}><Text style={styles.footerText}>Press Back to close</Text></View> : null}
        </Animated.View>
      </FocusBoundaryView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 80,
    elevation: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  focusBoundary: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  backdropBlur: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,12,28,0.18)',
  },
  backdropDim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(1,5,15,0.38)',
  },
  modal: {
    minWidth: 900,
    minHeight: 560,
    overflow: 'hidden',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(113,161,255,0.72)',
    backgroundColor: '#071326',
    paddingHorizontal: 26,
    paddingTop: 24,
    paddingBottom: 0,
    shadowColor: '#3B82F6',
    shadowOpacity: 0.26,
    shadowRadius: 24,
  },
  modalMovie: {
    minWidth: 0,
    minHeight: 0,
    paddingHorizontal: 20,
    paddingTop: 18,
  },
  modalBody: {
    flex: 1,
    minHeight: 0,
    flexDirection: 'row',
    gap: 22,
  },
  modalBodyMovie: {
    gap: 18,
  },
  posterColumn: {
    width: '24%',
    minWidth: 210,
    maxWidth: 270,
    gap: 12,
  },
  posterColumnMovie: {
    width: 190,
    minWidth: 180,
    maxWidth: 220,
    gap: 0,
  },
  posterFrame: {
    width: '100%',
    aspectRatio: 2 / 3,
    maxHeight: 356,
    overflow: 'hidden',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(143,177,255,0.44)',
    backgroundColor: '#0B1018',
  },
  posterFrameMovie: {
    maxHeight: 300,
  },
  posterImage: {
    ...StyleSheet.absoluteFillObject,
  },
  posterRating: {
    position: 'absolute',
    top: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(3,7,15,0.86)',
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  posterRatingText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },
  posterActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  movieActionRow: {
    flexDirection: 'row',
    flexWrap: 'nowrap',
    gap: 8,
    marginTop: 14,
  },
  actionMovie: {
    width: 'auto',
    flex: 1,
    minHeight: 44,
    paddingHorizontal: 6,
  },
  action: {
    minHeight: 46,
    width: '48%',
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'rgba(113,161,255,0.22)',
    backgroundColor: 'rgba(18,35,65,0.92)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingHorizontal: 8,
  },
  actionPrimary: {
    borderColor: '#4B8DFF',
    backgroundColor: '#1457C7',
  },
  actionFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: 0.48,
    shadowRadius: 8,
  },
  actionDisabled: {
    opacity: 0.42,
  },
  actionLabel: {
    color: novaTheme.colors.textPrimary,
    fontSize: 10,
    fontWeight: '800',
    textAlign: 'center',
  },
  actionLabelPrimary: {
    color: '#FFFFFF',
  },
  actionLabelDisabled: {
    color: novaTheme.colors.textMuted,
  },
  infoColumn: {
    flex: 1,
    minWidth: 0,
  },
  infoColumnMovie: {
    flex: 1,
  },
  infoContent: {
    paddingBottom: 16,
  },
  infoContentMovie: {
    paddingBottom: 4,
  },
  title: {
    color: novaTheme.colors.textPrimary,
    fontSize: 29,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  titleMovie: {
    fontSize: 26,
  },
  metaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: 6,
    marginTop: 12,
  },
  metaRowMovie: {
    marginTop: 8,
    gap: 5,
  },
  metaChip: {
    color: novaTheme.colors.textPrimary,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    paddingHorizontal: 7,
    paddingVertical: 4,
    fontSize: 11,
    fontWeight: '800',
  },
  ratingChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 4,
  },
  ratingChipText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 12,
    fontWeight: '800',
  },
  loadingText: {
    marginTop: 12,
    color: novaTheme.colors.accentHover,
    fontSize: 12,
    fontWeight: '700',
  },
  inlineError: {
    marginTop: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.45)',
    backgroundColor: 'rgba(127,29,29,0.18)',
    padding: 10,
    gap: 8,
  },
  inlineErrorText: {
    color: '#FCA5A5',
    fontSize: 12,
    fontWeight: '700',
  },
  sectionBlock: {
    marginTop: 18,
  },
  sectionBlockMovie: {
    marginTop: 12,
  },
  sectionLabel: {
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '900',
    marginBottom: 8,
  },
  description: {
    color: novaTheme.colors.textSecondary,
    fontSize: 13,
    lineHeight: 20,
  },
  descriptionMovie: {
    fontSize: 12,
    lineHeight: 18,
  },
  castRow: {
    gap: 10,
    paddingRight: 12,
  },
  castMember: {
    width: 82,
    minHeight: 116,
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    paddingVertical: 5,
  },
  castMemberFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
  castAvatar: {
    width: 58,
    height: 58,
    overflow: 'hidden',
    borderRadius: 29,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderStrong,
    backgroundColor: '#182A48',
    alignItems: 'center',
    justifyContent: 'center',
  },
  castImage: {
    width: '100%',
    height: '100%',
  },
  castInitials: {
    color: novaTheme.colors.textPrimary,
    fontSize: 16,
    fontWeight: '900',
  },
  castName: {
    marginTop: 6,
    color: novaTheme.colors.textPrimary,
    fontSize: 10,
    fontWeight: '800',
    textAlign: 'center',
  },
  castCharacter: {
    marginTop: 2,
    color: novaTheme.colors.textMuted,
    fontSize: 9,
    textAlign: 'center',
  },
  sideColumn: {
    width: '29%',
    minWidth: 280,
    maxWidth: 390,
    minHeight: 0,
    borderLeftWidth: 1,
    borderLeftColor: 'rgba(113,161,255,0.2)',
    paddingLeft: 18,
  },
  sidePanelContent: {
    flex: 1,
    minHeight: 0,
  },
  sideTitle: {
    color: novaTheme.colors.textPrimary,
    fontSize: 17,
    fontWeight: '900',
    marginBottom: 12,
  },
  seasonRow: {
    gap: 8,
    paddingBottom: 8,
  },
  seasonChip: {
    minHeight: 38,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
  },
  seasonChipSelected: {
    borderColor: novaTheme.colors.accent,
    backgroundColor: 'rgba(59,130,246,0.16)',
  },
  seasonChipFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
  seasonText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 11,
    fontWeight: '800',
  },
  seasonCount: {
    color: novaTheme.colors.textMuted,
    fontSize: 10,
    fontWeight: '800',
  },
  episodeScroll: {
    flex: 1,
    minHeight: 0,
  },
  episodeList: {
    gap: 7,
    paddingVertical: 4,
  },
  episodeRow: {
    minHeight: 58,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: novaTheme.colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingHorizontal: 10,
  },
  episodeRowFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
  episodeNumberBox: {
    width: 24,
    alignItems: 'center',
  },
  episodeNumber: {
    color: novaTheme.colors.textMuted,
    fontSize: 13,
    fontWeight: '900',
  },
  episodeCopy: {
    flex: 1,
    minWidth: 0,
  },
  episodeTitle: {
    color: novaTheme.colors.textPrimary,
    fontSize: 12,
    fontWeight: '800',
  },
  episodeMeta: {
    marginTop: 4,
    color: novaTheme.colors.textMuted,
    fontSize: 10,
    fontWeight: '600',
  },
  mutedCopy: {
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    lineHeight: 18,
  },
  metadataRow: {
    minHeight: 64,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(113,161,255,0.24)',
    backgroundColor: 'rgba(9,24,50,0.86)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
    paddingHorizontal: 14,
    marginTop: 12,
  },
  metadataItem: {
    flex: 1,
    minWidth: 0,
  },
  metadataLabel: {
    color: novaTheme.colors.textMuted,
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  metadataValue: {
    marginTop: 4,
    color: novaTheme.colors.textPrimary,
    fontSize: 11,
    fontWeight: '700',
  },
  footer: {
    minHeight: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerText: {
    color: novaTheme.colors.textMuted,
    fontSize: 11,
    fontWeight: '700',
  },
});
