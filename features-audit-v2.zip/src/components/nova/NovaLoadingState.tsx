import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

type NovaLoadingStateProps = {
  label?: string;
};

export function NovaLoadingState({ label = 'Loading...' }: NovaLoadingStateProps) {
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={novaTheme.colors.accent} />
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: novaTheme.spacing.lg,
    borderRadius: novaTheme.radius.md,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    gap: novaTheme.spacing.sm,
  },
  label: {
    color: novaTheme.colors.textSecondary,
    fontSize: novaTheme.typography.cardBody,
  },
});
