import { Image, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

type NovaLogoProps = {
  subtitle?: string;
  variant?: 'compact' | 'full' | 'mark';
  size?: 'sm' | 'md' | 'lg' | 'xl';
};

const markAsset = require('@/assets/images/nav-mark.png');

const markSizes = {
  sm: 38,
  md: 52,
  lg: 74,
  xl: 112,
} as const;

export function NovaLogo({ subtitle, variant = 'full', size = 'md' }: NovaLogoProps) {
  const markSize = markSizes[size];
  const showWordmark = variant !== 'mark';

  return (
    <View style={[styles.container, variant === 'compact' && styles.compact]}>
      <Image
        source={markAsset}
        style={{ width: markSize, height: markSize }}
        resizeMode="contain"
      />
      {showWordmark ? (
        <View style={styles.copy}>
          <Text
            style={[
              styles.wordmark,
              size === 'sm' && styles.wordmarkSm,
              size === 'lg' && styles.wordmarkLg,
              size === 'xl' && styles.wordmarkXl,
            ]}>
            NOVACAST
          </Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  compact: {
    gap: 8,
  },
  copy: {
    justifyContent: 'center',
  },
  wordmark: {
    color: novaTheme.colors.textPrimary,
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 1.8,
  },
  wordmarkSm: {
    fontSize: 18,
    letterSpacing: 1.2,
  },
  wordmarkLg: {
    fontSize: 32,
    letterSpacing: 2.2,
  },
  wordmarkXl: {
    fontSize: 42,
    letterSpacing: 2.8,
  },
  subtitle: {
    marginTop: 2,
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.4,
  },
});
