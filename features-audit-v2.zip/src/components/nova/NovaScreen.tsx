import type { PropsWithChildren } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import { StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { novaTheme } from '@/theme';

type NovaScreenProps = PropsWithChildren<{
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  padded?: boolean;
}>;

export function NovaScreen({ children, style, contentStyle, padded = true }: NovaScreenProps) {
  return (
    <View style={[styles.root, style]}>
      <SafeAreaView style={[styles.safeArea, padded && styles.padded, contentStyle]}>
        {children}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: novaTheme.colors.background,
  },
  safeArea: {
    flex: 1,
  },
  padded: {
    paddingTop: novaTheme.safeArea.top,
    paddingRight: novaTheme.safeArea.right,
    paddingBottom: novaTheme.safeArea.bottom,
    paddingLeft: novaTheme.safeArea.left,
  },
});
