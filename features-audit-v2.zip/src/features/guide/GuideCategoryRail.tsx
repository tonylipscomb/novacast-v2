import { memo, useCallback, useReducer, useRef, useState, type ElementRef } from 'react';
import { findNodeHandle, FlatList, Pressable, StyleSheet, Text } from 'react-native';

import type { ProviderLiveCategory } from '@/features/providers/providerRepositories';
import { novaTheme } from '@/theme';

type Focusable = ElementRef<typeof Pressable>;

export type GuideCategoryRailItem = Pick<ProviderLiveCategory, 'id' | 'renderKey' | 'name' | 'count'>;

type GuideCategoryRailProps = {
  categories: GuideCategoryRailItem[];
  selectedCategoryId: string;
  onSelect: (categoryId: string) => void;
  onFocusChange?: (focused: boolean) => void;
  registerItemRef?: (categoryId: string, instance: Focusable | null) => void;
};

function getHandle(instance: Focusable | null | undefined) {
  return instance ? findNodeHandle(instance) ?? undefined : undefined;
}

function formatCategoryCount(count: number | null) {
  if (count === null || count < 0) return '';
  return String(count);
}

type ChipProps = {
  category: GuideCategoryRailItem;
  selected: boolean;
  leftHandle?: number;
  rightHandle?: number;
  onRef: (instance: Focusable | null) => void;
  onFocus: () => void;
  onBlur: () => void;
  onPress: () => void;
};

const GuideCategoryChip = memo(function GuideCategoryChip({
  category,
  selected,
  leftHandle,
  rightHandle,
  onRef,
  onFocus,
  onBlur,
  onPress,
}: ChipProps) {
  const [isFocused, setIsFocused] = useState(false);
  const countText = formatCategoryCount(category.count);

  return (
    <Pressable
      ref={onRef}
      focusable
      accessibilityRole="button"
      accessibilityLabel={`Guide category ${category.name}`}
      {...(leftHandle !== undefined ? { nextFocusLeft: leftHandle } : null)}
      {...(rightHandle !== undefined ? { nextFocusRight: rightHandle } : null)}
      onFocus={() => {
        setIsFocused(true);
        onFocus();
      }}
      onBlur={() => {
        setIsFocused(false);
        onBlur();
      }}
      onPress={onPress}
      style={[styles.chipInner, selected && styles.chipInnerSelected, isFocused && styles.chipFocused]}>
      <Text numberOfLines={1} ellipsizeMode="tail" style={[styles.chipName, selected && styles.chipNameSelected]}>
        {category.name}
      </Text>
      {countText ? <Text numberOfLines={1} style={styles.chipCount}>{countText}</Text> : null}
    </Pressable>
  );
});

/**
 * Compact horizontal category rail above the Guide timeline. Mirrors
 * GuideScreen's established manual D-pad wiring pattern: left/right handles
 * are computed explicitly via findNodeHandle since a plain ScrollView gives
 * no native guarantee about horizontal focus search order across chips.
 * Up/down are left to Android's automatic nearest-neighbor focus search
 * (matching how the toolbar row above already behaves), so the rail composes
 * safely with the existing channel/program focus graph.
 */
export function GuideCategoryRail({ categories, selectedCategoryId, onSelect, onFocusChange, registerItemRef }: GuideCategoryRailProps) {
  const itemRefs = useRef<Record<string, Focusable | null>>({});
  const [, forceRefresh] = useReducer((count: number) => count + 1, 0);

  const setItemRef = useCallback(
    (categoryId: string, instance: Focusable | null) => {
      const hadHandle = getHandle(itemRefs.current[categoryId]) !== undefined;
      itemRefs.current[categoryId] = instance;
      registerItemRef?.(categoryId, instance);
      const hasHandle = getHandle(instance) !== undefined;
      if (hadHandle !== hasHandle) {
        requestAnimationFrame(() => forceRefresh());
      }
    },
    [registerItemRef],
  );

  const renderCategoryChip = useCallback(
    ({ item: category, index }: { item: GuideCategoryRailItem; index: number }) => {
      const previous = categories[index - 1];
      const next = categories[index + 1];
      return (
        <GuideCategoryChip
          category={category}
          selected={category.id === selectedCategoryId}
          leftHandle={previous ? getHandle(itemRefs.current[previous.id]) : undefined}
          rightHandle={next ? getHandle(itemRefs.current[next.id]) : undefined}
          onRef={(instance) => setItemRef(category.id, instance)}
          onFocus={() => onFocusChange?.(true)}
          onBlur={() => onFocusChange?.(false)}
          onPress={() => onSelect(category.id)}
        />
      );
    },
    [categories, onFocusChange, onSelect, selectedCategoryId, setItemRef],
  );

  if (!categories.length) {
    return null;
  }

  return (
    <FlatList
      horizontal
      data={categories}
      keyExtractor={(category) => category.renderKey}
      renderItem={renderCategoryChip}
      showsHorizontalScrollIndicator={false}
      style={styles.rail}
      contentContainerStyle={styles.railContent}
      initialNumToRender={categories.length}
      windowSize={21}
    />
  );
}

const styles = StyleSheet.create({
  rail: { minHeight: 46, maxHeight: 46 },
  railContent: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 2 },
  chipInner: {
    height: 40,
    minWidth: 72,
    maxWidth: 220,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: novaTheme.colors.surface,
    paddingHorizontal: 12,
  },
  chipInnerSelected: { backgroundColor: 'rgba(59,130,246,0.14)' },
  chipFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
  chipName: { flexShrink: 1, minWidth: 0, color: novaTheme.colors.textSecondary, fontSize: 13, fontWeight: '700' },
  chipNameSelected: { color: novaTheme.colors.textPrimary },
  chipCount: { color: novaTheme.colors.textMuted, fontSize: 10, fontWeight: '700' },
});
