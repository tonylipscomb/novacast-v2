import type { NormalizedGuideRow } from './guideTimeline';

export type GuideFilter = 'all' | 'favorites';

export function filterGuideRows(rows: NormalizedGuideRow[], filter: GuideFilter, favoriteIds: ReadonlySet<string>, query: string) {
  const normalizedQuery = query.trim().toLocaleLowerCase();

  return rows
    .map((row) => {
      const channelMatches = !normalizedQuery || row.channel.name.toLocaleLowerCase().includes(normalizedQuery);
      const programs = row.programs.filter(
        (program) => channelMatches || program.title.toLocaleLowerCase().includes(normalizedQuery),
      );
      const matchesFilter = filter === 'all' || favoriteIds.has(row.channel.id);
      if (!matchesFilter || (normalizedQuery && !channelMatches && !programs.length)) return null;
      return { ...row, programs: normalizedQuery && !channelMatches ? programs : row.programs };
    })
    .filter((row): row is NormalizedGuideRow => Boolean(row));
}

