/* eslint-disable react-hooks/set-state-in-effect -- Provider-backed screens load async repository data in effects. */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { getLiveTvMemory } from '@/features/live/liveTvMemory';
import { getLiveFavoriteEntries, usePersonalizationStore } from '@/features/personalization/personalizationStore';
import {
  fetchGuideRowsForChannels,
  XTREAM_GUIDE_CHANNEL_PAGE_SIZE,
  XTREAM_GUIDE_EPG_LIMIT,
  type ProviderGuideRow,
  type ProviderLiveCategory,
  type ProviderLiveChannel,
} from '@/features/providers/providerRepositories';
import { useActiveProviderBundle } from '@/features/providers/useActiveProviderBundle';
import type { ProviderRepositoryBundle } from '@/features/providers/providerBundle';

import { applyGuideCategoryResult, GUIDE_FAVORITES_CATEGORY_ID, statusForRows, type GuideLoadStatus } from './guideLogic';
import { getGuideMemory, rememberGuideMemory } from './guideMemory';
import { getGuideWindow, normalizeGuideRows, type NormalizedGuideRow } from './guideTimeline';

/** Synthetic category prepended before provider categories, mirroring Live TV's category rail. */
export const GUIDE_ALL_CATEGORY_ID = 'all';
export { GUIDE_FAVORITES_CATEGORY_ID };
export type { GuideLoadStatus };

type GuideCacheEntry = {
  rows: NormalizedGuideRow[];
  hasMore: boolean;
  totalCount: number | null;
};

const guideCache = new Map<string, GuideCacheEntry>();

/** `guideCache` must be scoped per category, not just per provider. */
function cacheKey(providerId: string, categoryId: string) {
  return `${providerId}:${categoryId}`;
}

export function clearGuideScreenCache() {
  guideCache.clear();
}

async function loadFavoriteGuideRows(bundle: ProviderRepositoryBundle, signal?: AbortSignal): Promise<ProviderGuideRow[]> {
  const entries = await getLiveFavoriteEntries(bundle.providerId);
  const channels = (
    await Promise.all(entries.map((entry) => bundle.live.getChannel(entry.contentId, signal).catch(() => null)))
  ).filter((channel): channel is ProviderLiveChannel => Boolean(channel));

  if (!channels.length) {
    return [];
  }

  return fetchGuideRowsForChannels(bundle.live, channels, XTREAM_GUIDE_EPG_LIMIT, signal);
}

export function useGuideScreenModel() {
  const { bundle } = useActiveProviderBundle();
  const providerId = bundle?.providerId ?? 'no-provider';
  const { state: personalizationState } = usePersonalizationStore(providerId);
  const favoritesAvailable = personalizationState.liveFavorites.length > 0;

  const [baseCategories, setBaseCategories] = useState<ProviderLiveCategory[]>([]);
  const [categoriesStatus, setCategoriesStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [selectedCategoryId, setSelectedCategoryId] = useState('');
  const [selectedCategoryTotalCount, setSelectedCategoryTotalCount] = useState<number | null>(null);
  const [status, setStatus] = useState<GuideLoadStatus>('loading');
  const [rows, setRows] = useState<NormalizedGuideRow[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const requestRef = useRef(0);
  const loadingMoreRef = useRef(false);
  const rowsRef = useRef<NormalizedGuideRow[]>([]);
  const selectedCategoryIdRef = useRef('');

  const categories = useMemo<ProviderLiveCategory[]>(() => {
    const countsKnown = baseCategories.length > 0 && baseCategories.every((category) => category.count != null);
    const allCategory: ProviderLiveCategory = {
      id: GUIDE_ALL_CATEGORY_ID,
      renderKey: GUIDE_ALL_CATEGORY_ID,
      name: 'All Channels',
      count: countsKnown ? baseCategories.reduce((total, category) => total + (category.count ?? 0), 0) : null,
      icon: 'earth',
    };
    const favoritesCategory: ProviderLiveCategory[] = favoritesAvailable
      ? [
          {
            id: GUIDE_FAVORITES_CATEGORY_ID,
            renderKey: GUIDE_FAVORITES_CATEGORY_ID,
            name: 'Favorites',
            count: personalizationState.liveFavorites.length,
            icon: 'star-outline' as const,
          },
        ]
      : [];

    return [allCategory, ...favoritesCategory, ...baseCategories];
  }, [baseCategories, favoritesAvailable, personalizationState.liveFavorites.length]);

  const applyResult = useCallback(
    (
      categoryId: string,
      requestId: number,
      nextRows: NormalizedGuideRow[],
      hasMoreLocal: boolean,
      totalCount: number | null,
      append: boolean,
    ) => {
      const result = applyGuideCategoryResult(rowsRef.current, {
        requestId,
        currentRequestId: requestRef.current,
        categoryId,
        nextRows,
        hasMore: hasMoreLocal,
        totalCount,
        append,
        favoritesAvailable,
      });

      if (!result.applied) {
        return;
      }

      rowsRef.current = result.rows;
      guideCache.set(cacheKey(providerId, categoryId), { rows: result.rows, hasMore: result.hasMore, totalCount: result.totalCount });
      setRows(result.rows);
      setHasMore(result.hasMore);
      setSelectedCategoryTotalCount(result.totalCount);
      setStatus(result.status);
      setErrorMessage(null);
    },
    [favoritesAvailable, providerId],
  );

  const loadCategoryPage = useCallback(
    async (categoryId: string, offset: number, requestId: number, append: boolean) => {
      if (!bundle) {
        return;
      }

      try {
        if (categoryId === GUIDE_FAVORITES_CATEGORY_ID) {
          if (offset > 0) {
            return;
          }
          const favoriteRows = await loadFavoriteGuideRows(bundle);
          if (requestId !== requestRef.current) {
            return;
          }
          const normalized = normalizeGuideRows(favoriteRows);
          applyResult(categoryId, requestId, normalized, false, normalized.length, append);
          return;
        }

        const providerCategoryId = categoryId === GUIDE_ALL_CATEGORY_ID ? undefined : categoryId;
        const cachedTotal = guideCache.get(cacheKey(providerId, categoryId))?.totalCount ?? null;
        const countPromise = append
          ? Promise.resolve(cachedTotal)
          : (bundle.guide.getChannelCount?.(providerCategoryId).catch(() => null) ?? Promise.resolve(null));

        const [pageRows, totalCount] = await Promise.all([
          bundle.guide.getRows(undefined, {
            categoryId: providerCategoryId,
            channelOffset: offset,
            channelLimit: XTREAM_GUIDE_CHANNEL_PAGE_SIZE,
          }),
          countPromise,
        ]);
        if (requestId !== requestRef.current) {
          return;
        }

        const normalized = normalizeGuideRows(pageRows);
        const hasMoreLocal = pageRows.length >= XTREAM_GUIDE_CHANNEL_PAGE_SIZE;
        applyResult(categoryId, requestId, normalized, hasMoreLocal, totalCount, append);
      } catch {
        if (requestId !== requestRef.current) {
          return;
        }
        if (!append && !rowsRef.current.length) {
          rowsRef.current = [];
          setRows([]);
          setStatus('error');
          setErrorMessage('Unable to load guide data from your provider.');
        }
      }
    },
    [applyResult, bundle, providerId],
  );

  const selectCategory = useCallback(
    (categoryId: string) => {
      if (!categoryId || !bundle || categoryId === selectedCategoryIdRef.current) {
        return;
      }

      const requestId = ++requestRef.current;
      selectedCategoryIdRef.current = categoryId;
      setSelectedCategoryId(categoryId);
      rememberGuideMemory(providerId, { selectedCategoryId: categoryId });

      const cached = guideCache.get(cacheKey(providerId, categoryId));
      if (cached) {
        rowsRef.current = cached.rows;
        setRows(cached.rows);
        setHasMore(cached.hasMore);
        setSelectedCategoryTotalCount(cached.totalCount);
        setStatus(statusForRows(categoryId, cached.rows, favoritesAvailable));
        setErrorMessage(null);
      } else {
        rowsRef.current = [];
        setRows([]);
        setHasMore(false);
        setSelectedCategoryTotalCount(null);
        setStatus('loading');
        setErrorMessage(null);
      }

      void loadCategoryPage(categoryId, 0, requestId, false);
    },
    [bundle, favoritesAvailable, loadCategoryPage, providerId],
  );

  const loadCategories = useCallback(async () => {
    if (!bundle) {
      setCategoriesStatus('error');
      setStatus('error');
      setErrorMessage('Provider is not connected.');
      return;
    }

    setCategoriesStatus('loading');
    try {
      const nextCategories = await bundle.live.getCategories();
      setBaseCategories(nextCategories);
      setCategoriesStatus('ready');

      const guideMemory = getGuideMemory(bundle.providerId);
      const liveMemory = getLiveTvMemory(bundle.providerId);
      const availableIds = new Set([
        GUIDE_ALL_CATEGORY_ID,
        ...(favoritesAvailable ? [GUIDE_FAVORITES_CATEGORY_ID] : []),
        ...nextCategories.map((category) => category.id),
      ]);

      const resolvedCategoryId =
        (guideMemory.selectedCategoryId && availableIds.has(guideMemory.selectedCategoryId) && guideMemory.selectedCategoryId) ||
        (liveMemory.selectedCategoryId && availableIds.has(liveMemory.selectedCategoryId) && liveMemory.selectedCategoryId) ||
        GUIDE_ALL_CATEGORY_ID;

      selectCategory(resolvedCategoryId);
    } catch {
      setCategoriesStatus('error');
      setStatus('error');
      setErrorMessage('Unable to load guide categories from your provider.');
    }
  }, [bundle, favoritesAvailable, selectCategory]);

  useEffect(() => {
    void loadCategories();
    return () => {
      requestRef.current += 1;
    };
  }, [bundle?.generation, loadCategories]);

  const loadMore = useCallback(async () => {
    if (!bundle || !hasMore || loadingMoreRef.current || !rowsRef.current.length) return;
    if (selectedCategoryIdRef.current === GUIDE_FAVORITES_CATEGORY_ID) return;

    loadingMoreRef.current = true;
    setIsLoadingMore(true);
    const requestId = requestRef.current;
    const categoryId = selectedCategoryIdRef.current;
    const offset = rowsRef.current.length;
    try {
      await loadCategoryPage(categoryId, offset, requestId, true);
    } finally {
      loadingMoreRef.current = false;
      setIsLoadingMore(false);
    }
  }, [bundle, hasMore, loadCategoryPage]);

  const reload = useCallback(() => {
    if (!bundle) {
      return;
    }

    if (!selectedCategoryIdRef.current || categoriesStatus === 'error') {
      void loadCategories();
      return;
    }

    const categoryId = selectedCategoryIdRef.current;
    guideCache.delete(cacheKey(providerId, categoryId));
    const requestId = ++requestRef.current;
    rowsRef.current = [];
    setRows([]);
    setHasMore(false);
    setStatus('loading');
    setErrorMessage(null);
    void loadCategoryPage(categoryId, 0, requestId, false);
  }, [bundle, categoriesStatus, loadCategories, loadCategoryPage, providerId]);

  const timeline = useMemo(() => getGuideWindow(rows), [rows]);
  const timeSlots = useMemo(() => {
    const slots: number[] = [];
    for (let timestamp = timeline.startAt; timestamp < timeline.endAt; timestamp += 60 * 60 * 1000) {
      slots.push(timestamp);
    }
    return slots;
  }, [timeline]);

  return {
    bundle,
    status: bundle ? status : 'error',
    rows,
    errorMessage: bundle ? errorMessage : 'Provider is not connected.',
    timeline,
    timeSlots,
    reload,
    loadMore,
    hasMore,
    isLoadingMore,
    categories,
    categoriesStatus,
    selectedCategoryId,
    selectCategory,
    selectedCategoryTotalCount,
  };
}
