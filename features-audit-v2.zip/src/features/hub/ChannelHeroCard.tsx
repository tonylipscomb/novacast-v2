import { useEffect, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';

import { categoryTypeAccentColor, categoryTypeLabel, type ProviderCategoryType } from '@/features/providers/categoryNormalization';
import { displayStreamTitle } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

type ChannelHeroCardProps = {
  title: string;
  subtitle: string;
  logoUrl?: string;
  categoryType: ProviderCategoryType;
  isLive?: boolean;
  preferredFocus?: boolean;
  focused: boolean;
  onFocus: () => void;
  onBlur: () => void;
  onPress: () => void;
};

/**
 * Glanceable Live TV channel card for the Home dashboard's "Favorite
 * Channels" / "Live Now" rows: a blurred, darkened backdrop built from the
 * channel's own logo (providers don't supply separate backdrop art), a
 * category-accent strip, a large sharp foreground logo with a soft halo for
 * legibility, and a text-based fallback when no logo is available at all.
 * Pure presentational component — accepts everything it needs as props and
 * does not reach into app/global state.
 */
export function ChannelHeroCard({
  title,
  subtitle,
  logoUrl,
  categoryType,
  isLive = false,
  preferredFocus = false,
  focused,
  onFocus,
  onBlur,
  onPress,
}: ChannelHeroCardProps) {
  const [scaleAnim] = useState(() => new Animated.Value(1));
  const accentColor = categoryTypeAccentColor(categoryType);
  const displayTitle = displayStreamTitle(title);

  useEffect(() => {
    Animated.timing(scaleAnim, {
      toValue: focused ? 1.07 : 1,
      duration: novaTheme.motion.normal,
      useNativeDriver: true,
    }).start();
  }, [focused, scaleAnim]);

  return (
    <View style={styles.wrap}>
      <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
        <Pressable
          focusable
          hasTVPreferredFocus={preferredFocus}
          onFocus={onFocus}
          onBlur={onBlur}
          onPress={onPress}
          style={[styles.card, focused && styles.focused]}>
          <View style={styles.artwork}>
            {logoUrl ? (
              <>
                <Image source={{ uri: logoUrl }} style={styles.backdropImage} contentFit="cover" blurRadius={22} />
                <View style={styles.backdropShade} pointerEvents="none" />
                <View style={styles.vignetteTop} pointerEvents="none" />
                <View style={styles.vignetteBottom} pointerEvents="none" />
                <View style={styles.logoHaloOuter} pointerEvents="none" />
                <View style={styles.logoHaloInner} pointerEvents="none" />
                <Image
                  source={{ uri: logoUrl }}
                  style={styles.foregroundLogo}
                  contentFit="contain"
                />
                <View style={[styles.accentStrip, { backgroundColor: accentColor }]} pointerEvents="none" />
              </>
            ) : (
              <View style={styles.textFallback}>
                <View style={[styles.accentStrip, { backgroundColor: accentColor }]} pointerEvents="none" />
                <View style={[styles.textFallbackTint, { backgroundColor: accentColor }]} pointerEvents="none" />
                <Text numberOfLines={2} style={styles.textFallbackTitle}>{displayTitle}</Text>
                <View style={[styles.textFallbackDivider, { backgroundColor: accentColor }]} />
                <Text numberOfLines={1} style={styles.textFallbackCategory}>{categoryTypeLabel(categoryType)}</Text>
              </View>
            )}
            {isLive ? (
              <View style={styles.liveBadge} pointerEvents="none">
                <Text style={styles.liveBadgeText}>LIVE</Text>
              </View>
            ) : null}
          </View>
          <Text numberOfLines={1} style={styles.title}>{displayTitle}</Text>
          <Text numberOfLines={1} style={styles.subtitle}>{subtitle}</Text>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: 168,
  },
  card: {
    width: 168,
    minHeight: 164,
    borderRadius: novaTheme.radius.md,
    borderWidth: 2,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    padding: 7,
  },
  focused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
  artwork: {
    height: 112,
    borderRadius: novaTheme.radius.sm,
    backgroundColor: novaTheme.colors.backgroundRaised,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  backdropImage: {
    ...StyleSheet.absoluteFillObject,
  },
  backdropShade: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(3,5,10,0.52)',
  },
  vignetteTop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '42%',
    backgroundColor: 'rgba(0,0,0,0.28)',
  },
  vignetteBottom: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '42%',
    backgroundColor: 'rgba(0,0,0,0.34)',
  },
  logoHaloOuter: {
    position: 'absolute',
    width: '78%',
    height: '78%',
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.22)',
  },
  logoHaloInner: {
    position: 'absolute',
    width: '58%',
    height: '58%',
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.28)',
  },
  foregroundLogo: {
    width: '86%',
    height: '86%',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.55,
    shadowRadius: 8,
    elevation: 6,
  },
  accentStrip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 4,
  },
  liveBadge: {
    position: 'absolute',
    top: 7,
    right: 7,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 999,
    backgroundColor: 'rgba(255,107,122,0.92)',
  },
  liveBadgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 0.6,
  },
  textFallback: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    backgroundColor: novaTheme.colors.backgroundRaised,
  },
  textFallbackTint: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.16,
  },
  textFallbackTitle: {
    color: novaTheme.colors.textPrimary,
    fontSize: 16,
    fontWeight: '800',
    textAlign: 'center',
  },
  textFallbackDivider: {
    marginTop: 7,
    width: 28,
    height: 2,
    borderRadius: 1,
  },
  textFallbackCategory: {
    marginTop: 7,
    color: novaTheme.colors.textSecondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 7,
    color: novaTheme.colors.textPrimary,
    fontSize: 13,
    fontWeight: '800',
  },
  subtitle: {
    marginTop: 3,
    color: novaTheme.colors.textMuted,
    fontSize: 11,
    fontWeight: '600',
  },
});
