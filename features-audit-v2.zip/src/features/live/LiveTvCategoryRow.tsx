import { memo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import type { ProviderLiveCategory } from '@/features/providers/providerRepositories';
import { novaTheme } from '@/theme';
import { formatLiveTvCategoryCount } from './liveTvCategoryCount';

type LiveTvCategoryRowProps = {
  category: ProviderLiveCategory;
  selected: boolean;
  preferFocus: boolean;
  onFocus: () => void;
  onPress: () => void;
};

function areLiveTvCategoryRowPropsEqual(previous: LiveTvCategoryRowProps, next: LiveTvCategoryRowProps) {
  return previous.category === next.category && previous.selected === next.selected && previous.preferFocus === next.preferFocus;
}

export const LiveTvCategoryRow = memo(function LiveTvCategoryRow({
  category,
  selected,
  preferFocus,
  onFocus,
  onPress,
}: LiveTvCategoryRowProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <Pressable
      focusable
      hasTVPreferredFocus={preferFocus}
      onFocus={() => {
        setIsFocused(true);
        onFocus();
      }}
      onBlur={() => setIsFocused(false)}
      onPress={onPress}
      style={[styles.categoryRow, selected && styles.selectedRow, isFocused && styles.focusedRow]}>
      <View style={styles.categoryLeft}>
        <Text numberOfLines={1} style={styles.categoryName}>
          {category.name}
        </Text>
      </View>
      <View style={styles.categoryRight}>
        <Text numberOfLines={1} style={styles.categoryCount}>
          {formatLiveTvCategoryCount(category.count)}
        </Text>
        {selected ? <View style={styles.selectedDot} /> : null}
      </View>
    </Pressable>
  );
}, areLiveTvCategoryRowPropsEqual);

const styles = StyleSheet.create({
  categoryRow: {
    minHeight: 40,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 2,
    borderColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  categoryLeft: {
    flex: 1,
    minWidth: 0,
  },
  categoryName: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
  },
  categoryRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  categoryCount: {
    minWidth: 34,
    marginLeft: 8,
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'right',
  },
  selectedDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: novaTheme.colors.accentHover,
  },
  selectedRow: {
    backgroundColor: 'rgba(59,130,246,0.10)',
  },
  focusedRow: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
});
