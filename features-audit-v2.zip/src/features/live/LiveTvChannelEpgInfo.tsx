import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

import { recordLiveTvEpgChildRender } from './liveTvScrollPerf';

export type LiveTvChannelEpgInfoProps = {
  current: string;
  progress: number;
  showProgress: boolean;
};

function epgPropsAreEqual(previous: LiveTvChannelEpgInfoProps, next: LiveTvChannelEpgInfoProps): boolean {
  return (
    previous.current === next.current &&
    previous.progress === next.progress &&
    previous.showProgress === next.showProgress
  );
}

export const LiveTvChannelEpgInfo = memo(function LiveTvChannelEpgInfo({
  current,
  progress,
  showProgress,
}: LiveTvChannelEpgInfoProps) {
  recordLiveTvEpgChildRender();

  return (
    <>
      <Text numberOfLines={1} style={styles.nowPlaying}>
        {current}
      </Text>
      {showProgress ? (
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${progress}%` }]} />
        </View>
      ) : (
        <View style={styles.progressSpacer} />
      )}
    </>
  );
}, epgPropsAreEqual);

const styles = StyleSheet.create({
  nowPlaying: {
    marginTop: 2,
    color: novaTheme.colors.textSecondary,
    fontSize: 11,
  },
  progressTrack: {
    height: 3,
    marginTop: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  progressFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: novaTheme.colors.accent,
  },
  progressSpacer: {
    height: 3,
    marginTop: 5,
  },
});
