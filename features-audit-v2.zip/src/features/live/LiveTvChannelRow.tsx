import type { ElementRef } from 'react';
import { memo, useCallback, useState } from 'react';
import { findNodeHandle, Platform, Pressable, StyleSheet, Text, View } from 'react-native';

import { displayStreamTitle } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

import type { LiveTvChannelEpgData, LiveTvChannelRowShellData } from './liveTvChannelRowData';
import { notifyLiveTvChannelFocusMove } from './liveTvFocusIdle';
import { getLiveTvRowVisualFlags } from './liveTvUiPerfMode';
import { recordLiveTvChannelFocus, recordLiveTvChannelRowRender } from './liveTvScrollPerf';

const rowVisualFlags = getLiveTvRowVisualFlags();

export type LiveTvChannelRowProps = {
  data: LiveTvChannelRowShellData;
  epg: LiveTvChannelEpgData;
  selected: boolean;
  previewing: boolean;
  preferFocus: boolean;
  trapFocusUp: boolean;
  trapFocusDown: boolean;
  onFocus: (channelId: string) => void;
  onTune: (channelId: string) => void;
  registerRef: (channelId: string, instance: ElementRef<typeof View> | null) => void;
};

function channelRowPropsAreEqual(previous: LiveTvChannelRowProps, next: LiveTvChannelRowProps): boolean {
  return (
    previous.data === next.data &&
    previous.epg === next.epg &&
    previous.selected === next.selected &&
    previous.previewing === next.previewing &&
    previous.preferFocus === next.preferFocus &&
    previous.trapFocusUp === next.trapFocusUp &&
    previous.trapFocusDown === next.trapFocusDown &&
    previous.onFocus === next.onFocus &&
    previous.onTune === next.onTune &&
    previous.registerRef === next.registerRef
  );
}

export const LiveTvChannelRow = memo(function LiveTvChannelRow({
  data,
  epg,
  selected,
  previewing,
  preferFocus,
  trapFocusUp,
  trapFocusDown,
  onFocus,
  onTune,
  registerRef,
}: LiveTvChannelRowProps) {
  recordLiveTvChannelRowRender();
  const [isFocused, setIsFocused] = useState(false);
  const [focusTrapHandle, setFocusTrapHandle] = useState<number | undefined>(undefined);

  const displayName = displayStreamTitle(data.name);
  const displayCurrent = displayStreamTitle(epg.current);
  const showSelected = rowVisualFlags.showSelectedHighlight && selected;
  const showPreviewing = rowVisualFlags.showPreviewingHighlight && previewing;

  const assignRef = useCallback(
    (instance: ElementRef<typeof View> | null) => {
      registerRef(data.id, instance);
      if (Platform.OS === 'android' && instance && (trapFocusUp || trapFocusDown)) {
        const handle = findNodeHandle(instance);
        setFocusTrapHandle(handle ?? undefined);
      }
    },
    [data.id, registerRef, trapFocusDown, trapFocusUp],
  );

  return (
    <Pressable
      ref={assignRef}
      focusable
      hasTVPreferredFocus={preferFocus}
      {...(trapFocusUp && focusTrapHandle ? { nextFocusUp: focusTrapHandle } : null)}
      {...(trapFocusDown && focusTrapHandle ? { nextFocusDown: focusTrapHandle } : null)}
      onFocus={() => {
        setIsFocused(true);
        recordLiveTvChannelFocus();
        notifyLiveTvChannelFocusMove();
        onFocus(data.id);
      }}
      onBlur={() => setIsFocused(false)}
      onPress={() => onTune(data.id)}
      style={[
        styles.channelRow,
        showSelected && styles.selectedRow,
        isFocused && (rowVisualFlags.lightweightFocus ? styles.focusedRowLight : styles.focusedRow),
        showPreviewing && styles.previewingRow,
      ]}>
      <Text style={styles.channelNumber}>{data.number}</Text>
      <View style={styles.channelCopy}>
        <View style={styles.channelNameRow}>
          <Text numberOfLines={1} style={styles.channelName}>
            {displayName}
          </Text>
          <Text numberOfLines={1} style={styles.nowPlaying}>
            {displayCurrent}
          </Text>
          {rowVisualFlags.showResolution ? <Text style={styles.resolution}>{data.resolution}</Text> : null}
        </View>
      </View>
    </Pressable>
  );
}, channelRowPropsAreEqual);

const styles = StyleSheet.create({
  channelRow: {
    height: 46,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 2,
    borderColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 7,
  },
  previewingRow: {
    backgroundColor: 'rgba(59,130,246,0.08)',
  },
  channelNumber: {
    width: 24,
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    textAlign: 'center',
  },
  channelCopy: {
    flex: 1,
    minWidth: 0,
  },
  channelNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  channelName: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '800',
  },
  nowPlaying: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    fontWeight: '600',
  },
  resolution: {
    color: novaTheme.colors.accentHover,
    fontSize: 9,
    fontWeight: '900',
  },
  selectedRow: {
    backgroundColor: 'rgba(59,130,246,0.10)',
  },
  focusedRow: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
  focusedRowLight: {
    borderColor: novaTheme.colors.focusRing,
  },
});
