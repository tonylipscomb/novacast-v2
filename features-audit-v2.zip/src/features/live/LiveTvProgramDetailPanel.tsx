import { memo } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

import type { ProviderLiveChannel } from '@/features/providers/providerRepositories';
import { displayLiveProgramText } from './liveTvProgramText';

const androidTextFit = Platform.OS === 'android' ? ({ includeFontPadding: false } as const) : {};

type LiveTvProgramDetailPanelProps = {
  channel: ProviderLiveChannel | null;
  previewWindow: string;
};

function panelPropsAreEqual(previous: LiveTvProgramDetailPanelProps, next: LiveTvProgramDetailPanelProps): boolean {
  if (previous.previewWindow !== next.previewWindow) {
    return false;
  }

  const prevChannel = previous.channel;
  const nextChannel = next.channel;

  if (prevChannel === nextChannel) {
    return true;
  }

  if (!prevChannel || !nextChannel || prevChannel.id !== nextChannel.id) {
    return false;
  }

  return (
    prevChannel.current === nextChannel.current &&
    prevChannel.currentStart === nextChannel.currentStart &&
    prevChannel.currentEnd === nextChannel.currentEnd &&
    prevChannel.remaining === nextChannel.remaining &&
    prevChannel.description === nextChannel.description &&
    prevChannel.resolution === nextChannel.resolution &&
    prevChannel.audio === nextChannel.audio
  );
}

export const LiveTvProgramDetailPanel = memo(function LiveTvProgramDetailPanel({
  channel,
  previewWindow,
}: LiveTvProgramDetailPanelProps) {
  const channelName = channel?.name ? displayLiveProgramText(channel.name, 'No channel selected') : 'No channel selected';
  const currentProgram = displayLiveProgramText(channel?.current, 'No program information available.');
  const description = displayLiveProgramText(channel?.description, 'No program information available.');

  return (
    <View style={styles.programInfo}>
      <View style={styles.programTopRow}>
        <View style={styles.programCopy}>
          <Text numberOfLines={1} style={styles.previewChannelName}>
            {channelName}
          </Text>
          <Text numberOfLines={2} style={styles.previewProgram}>
            {currentProgram}
          </Text>
          <Text style={styles.previewWindow}>{previewWindow}</Text>
        </View>
        <View style={styles.badges}>
          <Text style={styles.badge}>{channel?.resolution ?? 'HD'}</Text>
          <Text style={styles.badge}>{channel?.audio ?? 'Stereo'}</Text>
          <Text style={styles.badge}>{channel?.remaining ?? 'Live'}</Text>
        </View>
      </View>
      <Text numberOfLines={2} style={styles.description}>
        {description}
      </Text>
    </View>
  );
}, panelPropsAreEqual);

const styles = StyleSheet.create({
  programInfo: {
    minHeight: 0,
    flexShrink: 1,
    gap: 10,
    paddingTop: 0,
    paddingBottom: 0,
  },
  programTopRow: {
    flexDirection: 'column',
    alignItems: 'stretch',
    gap: 8,
  },
  programCopy: {
    flex: 0,
    minWidth: 0,
    gap: 4,
  },
  previewChannelName: {
    color: novaTheme.colors.textPrimary,
    fontSize: 18,
    lineHeight: 24,
    fontWeight: '800',
    ...androidTextFit,
  },
  previewProgram: {
    color: novaTheme.colors.textSecondary,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
    ...androidTextFit,
  },
  previewWindow: {
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '700',
    ...androidTextFit,
  },
  badges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    maxWidth: '100%',
    justifyContent: 'flex-start',
  },
  badge: {
    borderRadius: 999,
    backgroundColor: novaTheme.colors.surfaceMuted,
    color: novaTheme.colors.textSecondary,
    fontSize: 10,
    fontWeight: '800',
    paddingHorizontal: 8,
    paddingVertical: 4,
    overflow: 'hidden',
  },
  description: {
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    lineHeight: 18,
    ...androidTextFit,
  },
});
