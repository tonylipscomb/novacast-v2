import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState, type ElementRef } from 'react';
import { BackHandler, findNodeHandle, Pressable, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

import {
  CONTENT_SORT_OPTIONS,
  contentSortLabel,
  getVisibleSortOptions,
  type ContentSortOption,
} from './contentSorting';

export type ContentSortControlHandle = {
  focus: () => void;
};

type ContentSortControlProps = {
  value: ContentSortOption;
  onChange: (value: ContentSortOption) => void;
  showRating?: boolean;
};

export const ContentSortControl = forwardRef<ContentSortControlHandle, ContentSortControlProps>(function ContentSortControl(
  { value, onChange, showRating = true },
  ref,
) {
  const [open, setOpen] = useState(false);
  const [focusedTarget, setFocusedTarget] = useState<'trigger' | number | null>(null);
  const openerRef = useRef<ElementRef<typeof Pressable> | null>(null);
  const optionRefs = useRef<(ElementRef<typeof Pressable> | null)[]>([]);
  const [optionHandles, setOptionHandles] = useState<(number | null)[]>([]);

  const visibleOptions = useMemo(() => getVisibleSortOptions(showRating), [showRating]);

  useImperativeHandle(ref, () => ({
    focus: () => {
      openerRef.current?.focus();
    },
  }));

  const close = () => {
    setOpen(false);
    requestAnimationFrame(() => openerRef.current?.focus());
  };

  useEffect(() => {
    if (!open) return;
    const frame = requestAnimationFrame(() => {
      setOptionHandles(optionRefs.current.map((instance) => findNodeHandle(instance)));
    });
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      close();
      return true;
    });
    return () => {
      cancelAnimationFrame(frame);
      subscription.remove();
    };
  }, [open, visibleOptions.length]);

  useEffect(() => {
    if (value === 'rating-desc' && !showRating) {
      onChange('newest');
    }
  }, [onChange, showRating, value]);

  return (
    <View style={styles.root}>
      <Pressable
        ref={openerRef}
        focusable
        accessibilityRole="button"
        accessibilityLabel={`Sort: ${contentSortLabel(value)}`}
        onFocus={() => setFocusedTarget('trigger')}
        onBlur={() => setFocusedTarget(null)}
        onPress={() => setOpen((current) => !current)}
        style={[styles.trigger, focusedTarget === 'trigger' && styles.focused]}>
        <Text style={styles.triggerLabel}>Sort: {contentSortLabel(value)}</Text>
      </Pressable>
      {open ? (
        <View style={styles.menu}>
          {visibleOptions.map((option, index) => (
            <Pressable
              key={option.value}
              ref={(instance) => {
                optionRefs.current[index] = instance;
              }}
              focusable
              hasTVPreferredFocus={option.value === value}
              {...(optionHandles[index - 1] || (index === 0 && optionHandles[index])
                ? { nextFocusUp: optionHandles[index - 1] ?? optionHandles[index] }
                : null)}
              {...(optionHandles[index + 1] || (index === CONTENT_SORT_OPTIONS.length - 1 && optionHandles[index])
                ? { nextFocusDown: optionHandles[index + 1] ?? optionHandles[index] }
                : null)}
              {...(optionHandles[index] ? { nextFocusLeft: optionHandles[index], nextFocusRight: optionHandles[index] } : null)}
              onFocus={() => setFocusedTarget(index)}
              onBlur={() => setFocusedTarget(null)}
              onPress={() => {
                if (option.value !== value) {
                  onChange(option.value);
                }
                close();
              }}
              style={[styles.option, focusedTarget === index && styles.optionFocused, option.value === value && styles.optionSelected]}>
              <Text style={styles.optionText}>{option.label}</Text>
              {option.value === value ? <Text style={styles.check}>✓</Text> : null}
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  root: { position: 'relative', zIndex: 20 },
  trigger: {
    minHeight: 38,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  focused: { borderColor: novaTheme.colors.focusRing, backgroundColor: novaTheme.colors.surfaceFocused },
  triggerLabel: { color: novaTheme.colors.textPrimary, fontSize: 12, fontWeight: '800' },
  menu: {
    position: 'absolute',
    right: 0,
    top: 44,
    width: 190,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: '#111827',
    padding: 6,
    zIndex: 30,
  },
  option: {
    minHeight: 36,
    borderRadius: 8,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  optionFocused: { backgroundColor: novaTheme.colors.surfaceFocused, borderColor: novaTheme.colors.focusRing, borderWidth: 1 },
  optionSelected: { backgroundColor: 'rgba(59,130,246,0.16)' },
  optionText: { color: novaTheme.colors.textPrimary, fontSize: 12, fontWeight: '700' },
  check: { color: novaTheme.colors.accentHover, fontSize: 14, fontWeight: '900' },
});
