import type { MediaCategory } from './mediaTypes';

export function isSectionCategoryId(categoryId: string) {
  return categoryId.startsWith('section:');
}

export function isSmartCategoryId(categoryId: string) {
  return categoryId.startsWith('smart:');
}

export function isProviderCategory(category: MediaCategory) {
  return category.kind === 'provider' || (!isSmartCategoryId(category.id) && !isSectionCategoryId(category.id));
}

export function findDefaultProviderCategoryId(categories: MediaCategory[]) {
  const provider = categories.find((category) => category.kind === 'provider');
  if (provider) {
    return provider.id;
  }

  const legacyProvider = categories.find((category) => isProviderCategory(category) && category.kind !== 'section');
  if (legacyProvider) {
    return legacyProvider.id;
  }

  const smart = categories.find((category) => category.kind === 'smart');
  if (smart) {
    return smart.id;
  }

  return categories.find((category) => category.kind !== 'section')?.id ?? '';
}

export function prioritizeCategoryIds(categoryIds: string[], selectedCategoryId?: string, limit = 5) {
  const unique = [...new Set(categoryIds.filter(Boolean))];
  if (!selectedCategoryId) {
    return unique.slice(0, limit);
  }

  return [...new Set([selectedCategoryId, ...unique.filter((id) => id !== selectedCategoryId)])].slice(0, limit);
}
