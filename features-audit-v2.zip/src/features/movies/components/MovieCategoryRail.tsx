import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';

import { isProviderCategory } from '@/features/media-browser/mediaCategoryUtils';
import { ProviderCategoryMarker } from '@/components/ProviderCategoryMarker';
import { novaTheme } from '@/theme';

import type { MovieCategory } from '../movieTypes';

const PROVIDER_SECTION_ID = 'section:provider';

type MovieCategoryRailProps = {
  categories: MovieCategory[];
  selectedCategoryId: string;
  preferredCategoryId?: string | null;
  discoverStatusMessage?: string | null;
  onSelectCategory: (categoryId: string) => void;
  onPrefetchCategoryCount?: (categoryId: string) => void;
};

export function MovieCategoryRail({
  categories,
  selectedCategoryId,
  preferredCategoryId,
  discoverStatusMessage,
  onSelectCategory,
  onPrefetchCategoryCount,
}: MovieCategoryRailProps) {
  const [focusedCategoryId, setFocusedCategoryId] = useState<string | null>(null);

  return (
    <View style={styles.panel}>
      <View style={styles.header}>
        <Text style={styles.title}>Categories</Text>
        <MaterialCommunityIcons name="view-list-outline" size={18} color={novaTheme.colors.textMuted} />
      </View>

      {discoverStatusMessage ? (
        <View style={styles.discoverStatus}>
          <Text style={styles.discoverStatusText}>{discoverStatusMessage}</Text>
        </View>
      ) : null}

      <FlatList
        data={categories}
        keyExtractor={(item) => item.renderKey}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        style={styles.listContainer}
        removeClippedSubviews={false}
        initialNumToRender={Math.min(categories.length, 16)}
        maxToRenderPerBatch={8}
        windowSize={5}
        renderItem={({ item }) => {
          if (item.kind === 'section') {
            if (item.id === PROVIDER_SECTION_ID) {
              return (
                <View style={styles.providerSeparator}>
                  <View style={styles.providerSeparatorGlow} />
                  <View style={styles.providerSeparatorLine} />
                </View>
              );
            }

            return (
              <View style={styles.sectionRow}>
                <Text style={styles.sectionLabel}>{item.name}</Text>
              </View>
            );
          }

          const selected = item.id === selectedCategoryId;
          const displayName = item.name;
          const countryCode = item.countryCode;
          const regionMarker = item.regionMarker;
          const showMarker = isProviderCategory(item) && (Boolean(countryCode) || regionMarker === 'multi');

          return (
            <Pressable
              focusable
              hasTVPreferredFocus={Boolean(preferredCategoryId && item.id === preferredCategoryId)}
              onFocus={() => {
                setFocusedCategoryId(item.id);
                if (item.kind !== 'smart' && item.kind !== 'section') {
                  onPrefetchCategoryCount?.(item.id);
                }
              }}
              onBlur={() => setFocusedCategoryId(null)}
              onPress={() => onSelectCategory(item.id)}
              style={[
                styles.row,
                selected && styles.rowSelected,
                focusedCategoryId === item.id && styles.rowFocused,
              ]}>
              {showMarker ? (
                <ProviderCategoryMarker
                  countryCode={countryCode}
                  regionMarker={regionMarker}
                  size="lg"
                />
              ) : null}
              <Text numberOfLines={1} style={[styles.name, selected && styles.nameSelected]}>
                {displayName}
              </Text>
              <Text style={[styles.count, selected && styles.countSelected]}>
                {item.countKnown === false ? '-' : item.count.toLocaleString()}
              </Text>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    width: 220,
    minWidth: 220,
    maxWidth: 220,
    flexShrink: 0,
    flex: 1,
    minHeight: 0,
    borderRadius: novaTheme.radius.lg,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.backgroundRaised,
    padding: 10,
  },
  header: {
    minHeight: 40,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 6,
  },
  title: {
    color: novaTheme.colors.textPrimary,
    fontSize: 20,
    fontWeight: '800',
  },
  list: {
    gap: 6,
    paddingTop: 4,
    paddingBottom: 10,
  },
  listContainer: {
    flex: 1,
    minHeight: 0,
  },
  row: {
    minHeight: 44,
    borderRadius: novaTheme.radius.md,
    borderWidth: 1,
    borderColor: 'transparent',
    backgroundColor: novaTheme.colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    paddingHorizontal: 10,
  },
  rowSelected: {
    backgroundColor: 'rgba(59,130,246,0.18)',
    borderColor: 'rgba(97,165,255,0.42)',
  },
  rowFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
  name: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textSecondary,
    fontSize: 14,
    fontWeight: '700',
  },
  nameSelected: {
    color: novaTheme.colors.textPrimary,
  },
  count: {
    flexShrink: 0,
    minWidth: 36,
    textAlign: 'right',
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    fontWeight: '700',
  },
  countSelected: {
    color: novaTheme.colors.textPrimary,
  },
  sectionRow: {
    minHeight: 36,
    justifyContent: 'center',
    paddingHorizontal: 8,
    marginTop: 4,
  },
  sectionLabel: {
    color: novaTheme.colors.textMuted,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
  },
  discoverStatus: {
    borderRadius: novaTheme.radius.md,
    backgroundColor: 'rgba(59,130,246,0.12)',
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 6,
  },
  discoverStatusText: {
    color: novaTheme.colors.accentHover,
    fontSize: 11,
    fontWeight: '700',
  },
  providerSeparator: {
    minHeight: 20,
    justifyContent: 'center',
    paddingHorizontal: 6,
    marginTop: 4,
    marginBottom: 2,
  },
  providerSeparatorGlow: {
    position: 'absolute',
    left: 8,
    right: 8,
    height: 1,
    backgroundColor: 'rgba(97,165,255,0.35)',
    shadowColor: novaTheme.colors.accentHover,
    shadowOpacity: 0.45,
    shadowRadius: 6,
  },
  providerSeparatorLine: {
    height: 1,
    borderRadius: 1,
    backgroundColor: 'rgba(255,255,255,0.14)',
  },
});
