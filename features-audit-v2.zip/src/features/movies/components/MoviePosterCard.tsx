import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { ElementRef } from 'react';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { TvRemoteImage } from '@/components/media/TvRemoteImage';
import { displayStreamTitle, formatMediaMetaLabel } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

import type { MovieSummary } from '../movieTypes';

type MoviePosterCardProps = {
  movie: MovieSummary;
  isSelected?: boolean;
  hasPreferredFocus?: boolean;
  onFocus: (movie: MovieSummary) => void;
  onPress?: (movie: MovieSummary) => void;
  registerRef?: (instance: ElementRef<typeof Pressable> | null) => void;
  isDiscover?: boolean;
};

const POSTER_THEMES: Record<
  string,
  { background: string; glow: string; accent: string; accentSoft: string; secondary: string }
> = {
  ember: { background: '#101318', glow: 'rgba(255,134,74,0.20)', accent: '#FF9A52', accentSoft: 'rgba(255,154,82,0.24)', secondary: '#FF6F61' },
  signal: { background: '#0E1420', glow: 'rgba(97,165,255,0.20)', accent: '#5FA8FF', accentSoft: 'rgba(95,168,255,0.22)', secondary: '#8B7BFF' },
  glacier: { background: '#10161A', glow: 'rgba(78,208,192,0.18)', accent: '#72E5D6', accentSoft: 'rgba(114,229,214,0.22)', secondary: '#B1F0EA' },
  orbit: { background: '#11131D', glow: 'rgba(140,110,255,0.20)', accent: '#B28BFF', accentSoft: 'rgba(178,139,255,0.22)', secondary: '#68B7FF' },
  midnight: { background: '#111217', glow: 'rgba(255,255,255,0.10)', accent: '#E0E6FF', accentSoft: 'rgba(255,255,255,0.14)', secondary: '#81A8FF' },
  onyx: { background: '#0D1117', glow: 'rgba(255,255,255,0.08)', accent: '#AEB8C8', accentSoft: 'rgba(174,184,200,0.16)', secondary: '#6B7A90' },
  aurora: { background: '#10161D', glow: 'rgba(87,255,205,0.16)', accent: '#6FFFCB', accentSoft: 'rgba(111,255,203,0.18)', secondary: '#80A8FF' },
  dune: { background: '#121118', glow: 'rgba(255,197,110,0.18)', accent: '#FFD07A', accentSoft: 'rgba(255,208,122,0.2)', secondary: '#FF9F6B' },
};

function getPosterColors(key: string) {
  return POSTER_THEMES[key] ?? POSTER_THEMES.midnight;
}

function makeInitials(title: string) {
  return title
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');
}

export function MoviePosterCard({
  movie,
  isSelected = false,
  hasPreferredFocus,
  onFocus,
  onPress,
  registerRef,
  isDiscover = false,
}: MoviePosterCardProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [failedPosterKey, setFailedPosterKey] = useState<string | null>(null);
  const theme = getPosterColors(movie.posterStyleKey);
  const initials = makeInitials(movie.title);
  const posterKey = `${movie.id}:${movie.posterUrl ?? ''}`;
  const posterFailed = failedPosterKey === posterKey;
  const showPosterArt = Boolean(movie.posterUrl) && !posterFailed;
  const metaPrimary = formatMediaMetaLabel({
    year: movie.year,
    rating: movie.rating,
    genre: movie.genres[0],
  });

  return (
    <Pressable
      ref={registerRef}
      focusable
      hasTVPreferredFocus={hasPreferredFocus}
      onFocus={() => {
        setIsFocused(true);
        onFocus(movie);
      }}
      onBlur={() => setIsFocused(false)}
      onPress={() => onPress?.(movie)}
      style={[
        styles.card,
        isDiscover && styles.cardDiscover,
        isSelected && styles.cardSelected,
        isFocused && styles.cardFocused,
        isFocused && { borderColor: novaTheme.colors.focusRing },
      ]}>
      <View style={[styles.poster, isDiscover && styles.posterDiscover, showPosterArt ? styles.posterWithArt : { backgroundColor: theme.background }]}>
        {showPosterArt ? (
          <>
            <TvRemoteImage uri={movie.posterUrl} style={styles.posterImage} onError={() => setFailedPosterKey(posterKey)} />
            {movie.rating ? (
              <View style={styles.ratingBadge}>
                <MaterialCommunityIcons name="star" size={10} color="#F6C85F" />
                <Text style={styles.ratingText}>{movie.rating}</Text>
              </View>
            ) : null}
          </>
        ) : (
          <>
            <View style={[styles.posterFrame, { borderColor: theme.accentSoft }]} />
            <View style={[styles.posterBandTop, { backgroundColor: theme.glow }]} />
            <View style={[styles.posterBandBottom, { backgroundColor: theme.accentSoft }]} />
            <View style={styles.posterHeader}>
              <Text style={[styles.posterTag, { color: theme.secondary }]}>FEATURE</Text>
              <Text style={[styles.posterYear, { color: theme.secondary }]}>{metaPrimary}</Text>
            </View>
            <View style={styles.posterCenter}>
              <Text style={[styles.initials, { color: theme.accent }]}>{initials}</Text>
              <Text numberOfLines={1} style={[styles.posterGenre, { color: theme.accentSoft }]}>
                {movie.genres[0] ?? 'Feature'}
              </Text>
            </View>
            <View style={styles.posterFooter}>
              <Text numberOfLines={1} style={styles.posterFooterLabel}>
                {displayStreamTitle(movie.title)}
              </Text>
            </View>
            {movie.rating ? (
              <View style={styles.ratingBadge}>
                <MaterialCommunityIcons name="star" size={10} color={theme.accent} />
                <Text style={styles.ratingText}>{movie.rating}</Text>
              </View>
            ) : null}
          </>
        )}
      </View>

      <Text numberOfLines={1} style={styles.title}>
        {displayStreamTitle(movie.title)}
      </Text>
      <View style={styles.metaRow}>
        {metaPrimary ? <Text style={styles.meta}>{metaPrimary}</Text> : null}
        {metaPrimary && movie.genres[0] ? <View style={styles.metaDot} /> : null}
        <Text style={styles.meta}>{movie.genres[0] ?? 'Feature'}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 0,
    borderRadius: novaTheme.radius.md,
    borderWidth: 1,
    borderColor: 'transparent',
    padding: 4,
  },
  cardSelected: {
    borderColor: novaTheme.colors.accent,
    backgroundColor: 'rgba(59,130,246,0.05)',
  },
  cardFocused: {
    backgroundColor: 'rgba(59,130,246,0.08)',
    borderColor: novaTheme.colors.focusRing,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: 0.28,
    shadowRadius: 10,
  },
  poster: {
    aspectRatio: 2 / 3,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
    padding: 10,
  },
  cardDiscover: {
    padding: 6,
  },
  posterDiscover: {
    aspectRatio: 16 / 10,
  },
  posterWithArt: {
    padding: 0,
    backgroundColor: '#0B1018',
  },
  posterImage: {
    ...StyleSheet.absoluteFill,
  },
  posterFrame: {
    position: 'absolute',
    top: 10,
    right: 10,
    bottom: 10,
    left: 10,
    borderWidth: 1,
    borderRadius: novaTheme.radius.sm,
    opacity: 0.9,
  },
  posterBandTop: {
    position: 'absolute',
    left: 10,
    right: 10,
    top: 10,
    height: 2,
    opacity: 0.9,
  },
  posterBandBottom: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 38,
    height: 3,
    opacity: 0.55,
  },
  posterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  posterTag: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  posterYear: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  posterCenter: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
  },
  initials: {
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  posterGenre: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  posterFooter: {
    minHeight: 20,
    justifyContent: 'flex-end',
  },
  posterFooterLabel: {
    color: novaTheme.colors.textPrimary,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  ratingBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(5,9,15,0.78)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  ratingText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 10,
    fontWeight: '800',
  },
  title: {
    marginTop: 6,
    color: novaTheme.colors.textPrimary,
    fontSize: 12,
    fontWeight: '700',
  },
  metaRow: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  meta: {
    color: novaTheme.colors.textMuted,
    fontSize: 10,
    fontWeight: '600',
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 99,
    backgroundColor: novaTheme.colors.textMuted,
  },
});
