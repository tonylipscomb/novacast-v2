import type { ElementRef } from 'react';
import { useEffect, useRef } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { novaTheme } from '@/theme';
import { ContentSortControl, type ContentSortControlHandle } from '@/features/media-browser/ContentSortControl';
import type { ContentSortOption } from '@/features/media-browser/contentSorting';

import type { MovieSummary } from '../movieTypes';
import { MoviePosterCard } from './MoviePosterCard';

type MoviePosterGridProps = {
  movies: MovieSummary[];
  selectedCategoryLabel: string;
  selectedCategoryId: string;
  columns: number;
  hasMore: boolean;
  loading: boolean;
  focusedMovieId: string | null;
  selectedMovieId: string | null;
  onFocusMovie: (movie: MovieSummary) => void;
  onSelectMovie: (movie: MovieSummary) => void;
  registerPosterRef?: (movieId: string, instance: ElementRef<typeof View> | null) => void;
  loadMore: () => void;
  sortOption: ContentSortOption;
  onSortChange: (value: ContentSortOption) => void;
  showRatingSort?: boolean;
  isDiscover?: boolean;
  emptyNotice?: string | null;
};

export function MoviePosterGrid({
  movies,
  selectedCategoryLabel,
  selectedCategoryId,
  columns,
  hasMore,
  loading,
  focusedMovieId,
  selectedMovieId,
  onFocusMovie,
  onSelectMovie,
  registerPosterRef,
  loadMore,
  sortOption,
  onSortChange,
  showRatingSort = true,
  isDiscover = false,
  emptyNotice = null,
}: MoviePosterGridProps) {
  const gridHeaderSuffix = loading ? 'Loading' : hasMore ? 'More available' : `${movies.length} items`;
  const loadMoreThreshold = Math.max(columns * 2, movies.length - columns * 2);
  const firstMovieId = movies[0]?.id;
  const focusSeedRef = useRef<string | null>(null);
  const focusClaimedRef = useRef(false);
  const firstCardRef = useRef<ElementRef<typeof View> | null>(null);
  const sortControlRef = useRef<ContentSortControlHandle | null>(null);
  const sortMountedRef = useRef(false);

  useEffect(() => {
    focusClaimedRef.current = false;
    focusSeedRef.current = selectedMovieId ?? firstMovieId ?? null;
  }, [firstMovieId, selectedCategoryId, selectedMovieId]);

  useEffect(() => {
    if (!sortMountedRef.current) {
      sortMountedRef.current = true;
      return;
    }
    if (!loading) {
      requestAnimationFrame(() => sortControlRef.current?.focus());
    }
  }, [loading, sortOption]);

  return (
    <View style={styles.panel}>
      <View style={styles.header}>
        <Text numberOfLines={1} style={styles.title}>
          {selectedCategoryLabel}
        </Text>
        <View style={styles.sortGroup}>
          <ContentSortControl ref={sortControlRef} value={sortOption} onChange={onSortChange} showRating={showRatingSort} />
          <Text style={styles.subtitle}>{gridHeaderSuffix}</Text>
        </View>
      </View>

      {emptyNotice ? (
        <View style={styles.emptyNotice}>
          <MaterialCommunityIcons
            name={emptyNotice.includes('display') ? 'cloud-off-outline' : 'movie-off-outline'}
            size={22}
            color={novaTheme.colors.textMuted}
          />
          <Text style={styles.emptyNoticeText}>{emptyNotice}</Text>
        </View>
      ) : (
      <FlatList
        data={movies}
        key={columns}
        numColumns={columns}
        keyExtractor={(item) => item.id}
        scrollEnabled
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        columnWrapperStyle={columns > 1 ? styles.row : undefined}
        removeClippedSubviews={false}
        windowSize={5}
        initialNumToRender={columns * 3}
        onEndReachedThreshold={0.35}
        onEndReached={() => {
          if (hasMore && !loading) {
            loadMore();
          }
        }}
        renderItem={({ item, index }) => (
          <MoviePosterCard
            movie={item}
            isDiscover={isDiscover}
            isSelected={item.id === selectedMovieId}
            hasPreferredFocus={
              !focusClaimedRef.current &&
              !loading &&
              item.id === focusSeedRef.current
            }
            onFocus={(movie) => {
              focusClaimedRef.current = true;
              onFocusMovie(movie);
              if (hasMore && !loading && index >= loadMoreThreshold) {
                loadMore();
              }
            }}
            onPress={(movie) => {
              onSelectMovie(movie);
            }}
            registerRef={(instance) => {
              if (item.id === firstMovieId) firstCardRef.current = instance;
              registerPosterRef?.(item.id, instance);
            }}
          />
        )}
      />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    flex: 1,
    minWidth: 0,
    borderRadius: novaTheme.radius.lg,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.backgroundRaised,
    paddingHorizontal: 14,
    paddingTop: 12,
  },
  header: {
    minHeight: 40,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingHorizontal: 2,
  },
  title: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textPrimary,
    fontSize: 20,
    fontWeight: '800',
  },
  subtitle: {
    color: novaTheme.colors.textMuted,
    fontSize: 12,
    fontWeight: '700',
  },
  sortGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  list: {
    paddingTop: 4,
    paddingBottom: 26,
    paddingHorizontal: 2,
  },
  row: {
    gap: 8,
    marginBottom: 10,
  },
  emptyNotice: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  emptyNoticeText: {
    color: novaTheme.colors.textMuted,
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
});
