import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

type MovieToolbarProps = {
  onSearchPress: () => void;
  onFilterPress: () => void;
};

export function MovieToolbar({ onSearchPress, onFilterPress }: MovieToolbarProps) {
  const [focusedId, setFocusedId] = useState<'search' | 'filter' | null>(null);

  return (
    <View style={styles.toolbar}>
      <Pressable
        focusable
        onFocus={() => setFocusedId('search')}
        onBlur={() => setFocusedId(null)}
        onPress={onSearchPress}
        style={[styles.iconButton, focusedId === 'search' && styles.iconButtonFocused]}>
        <MaterialCommunityIcons name="magnify" size={22} color={novaTheme.colors.textPrimary} />
        <Text style={styles.iconText}>Search</Text>
      </Pressable>
      <Pressable
        focusable
        onFocus={() => setFocusedId('filter')}
        onBlur={() => setFocusedId(null)}
        onPress={onFilterPress}
        style={[styles.chipButton, focusedId === 'filter' && styles.chipButtonFocused]}>
        <MaterialCommunityIcons name="filter-outline" size={18} color={novaTheme.colors.textPrimary} />
        <Text style={styles.chipText}>Filter</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconButton: {
    minHeight: 42,
    height: 42,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 12,
  },
  iconButtonFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
  iconText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '700',
  },
  chipButton: {
    minHeight: 42,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: novaTheme.colors.borderSubtle,
    backgroundColor: novaTheme.colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 6,
    paddingHorizontal: 13,
  },
  chipButtonFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
  chipText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '700',
  },
});
