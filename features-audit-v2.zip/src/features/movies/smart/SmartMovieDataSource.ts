import type { MovieDataSource } from '../data/MovieDataSource.ts';
import type { MovieSummary, MovieCategory } from '../movieTypes.ts';
import { SMART_CATEGORY_PREFIX } from '../movieTypes.ts';
import {
  buildContentSortPageMetadata,
  categoryHasValidRatings,
  DEFAULT_CONTENT_SORT,
  paginateSortedItems,
  sortContentItems,
  type ContentSortOption,
} from '../../media-browser/contentSorting.ts';
import { getCategoryCountFromIndex } from '../../providers/categoryCountIndexStore.ts';
import { fallbackProviderCategoryId } from '../../providers/categoryNormalization.ts';
import {
  getSmartCategoryCountSync,
  getSmartCategoryEntrySync,
  getSmartCategoryCacheSync,
} from '../../providers/smartCategoryCacheStore.ts';
import { loadAllMoviesForCatalogIndex } from '../../providers/catalogCategoryLoader.ts';
import { logSmartCategoryCatalogAudit } from '../../providers/catalogSyncAudit.ts';
import { entryToSummary, getMovieCatalogIndex, type MovieCatalogEntry } from './movieCatalogIndex.ts';
import {
  getContinueWatchingIds,
  getFavoriteIds,
  getLastWatchedMovie,
  getRecentlyWatchedIds,
  getWatchlistIds,
} from './movieLibraryStore.ts';
import { getMoviesSettings } from './moviesSettingsStore.ts';
import {
  buildSmartCategoryContext,
  getActiveSmartCategoryDefinitions,
  querySmartCategoryOnIndex,
  resolveSmartCategoryDefinition,
} from './smartCategoryDefinitions.ts';

export const SECTION_DISCOVER_ID = 'section:discover';
export const SECTION_PROVIDER_ID = 'section:provider';

function appendFallbackCategory(categories: MovieCategory[], providerId: string) {
  const id = fallbackProviderCategoryId('movie');
  const count = getCategoryCountFromIndex(providerId, 'movie', id);
  if (count == null || count <= 0 || categories.some((category) => category.id === id)) {
    return categories;
  }

  return [
    ...categories,
    {
      id,
      renderKey: `${id}::fallback`,
      name: 'Uncategorized',
      count,
      countKnown: true,
      kind: 'provider' as const,
      section: 'provider' as const,
    },
  ];
}

const indexListeners = new Map<string, Set<() => void>>();

function isSmartCategoryId(categoryId: string) {
  return categoryId.startsWith(SMART_CATEGORY_PREFIX);
}

function isSectionCategoryId(categoryId: string) {
  return categoryId.startsWith('section:');
}

function isProviderCategoryId(categoryId: string) {
  return !isSmartCategoryId(categoryId) && !isSectionCategoryId(categoryId);
}

export function subscribeCatalogIndex(providerId: string, listener: () => void) {
  const listeners = indexListeners.get(providerId) ?? new Set();
  listeners.add(listener);
  indexListeners.set(providerId, listeners);
  return () => {
    listeners.delete(listener);
    if (!listeners.size) {
      indexListeners.delete(providerId);
    }
  };
}

async function buildLibraryContext(providerId: string) {
  const [favorites, watchlist, continueWatching, recentlyWatched, lastWatched] = await Promise.all([
    getFavoriteIds(providerId),
    getWatchlistIds(providerId),
    getContinueWatchingIds(providerId),
    getRecentlyWatchedIds(providerId),
    getLastWatchedMovie(providerId),
  ]);

  const index = getMovieCatalogIndex(providerId);
  const lastEntry = lastWatched ? index.getEntry(lastWatched.movieId) : undefined;

  return buildSmartCategoryContext({
    providerId,
    favorites,
    watchlist,
    continueWatching,
    recentlyWatched,
    lastWatchedGenres: lastEntry?.genreTags ?? [],
  });
}

export function createSmartMovieDataSource(base: MovieDataSource, providerId: string): MovieDataSource {
  async function buildSmartCategories(providerCategories: MovieCategory[]) {
    const settings = await getMoviesSettings();
    if (settings.hideSmartCategories) {
      return appendFallbackCategory(providerCategories.map((category) => ({
        ...category,
        kind: 'provider' as const,
        section: 'provider' as const,
        count: getCategoryCountFromIndex(providerId, 'movie', category.id) ?? category.count,
        countKnown: getCategoryCountFromIndex(providerId, 'movie', category.id) !== undefined || category.countKnown !== false,
      })), providerId);
    }

    const definitions = getActiveSmartCategoryDefinitions();
    const smartCache = getSmartCategoryCacheSync(providerId, 'movie');

    const smartCategories: MovieCategory[] = definitions.map((definition) => ({
      id: `${SMART_CATEGORY_PREFIX}${definition.key}`,
      renderKey: `${SMART_CATEGORY_PREFIX}${definition.key}`,
      name: `${definition.icon} ${definition.name}`,
      icon: definition.icon,
      smartKey: definition.key,
      kind: 'smart' as const,
      section: 'discover' as const,
      count: smartCache.entries[definition.key]?.count ?? getSmartCategoryCountSync(providerId, 'movie', definition.key),
      countKnown: smartCache.entries[definition.key] !== undefined,
    }));

    const providerWithKind: MovieCategory[] = providerCategories.map((category) => ({
      ...category,
      kind: 'provider' as const,
      section: 'provider' as const,
      count: getCategoryCountFromIndex(providerId, 'movie', category.id) ?? category.count,
      countKnown: getCategoryCountFromIndex(providerId, 'movie', category.id) !== undefined || category.countKnown !== false,
    }));
    const providerWithFallback = appendFallbackCategory(providerWithKind, providerId);

    return [
      {
        id: SECTION_DISCOVER_ID,
        renderKey: SECTION_DISCOVER_ID,
        name: 'Discover',
        count: 0,
        kind: 'section' as const,
        section: 'discover' as const,
      },
      ...smartCategories,
      {
        id: SECTION_PROVIDER_ID,
        renderKey: SECTION_PROVIDER_ID,
        name: 'From Your Provider',
        count: 0,
        kind: 'section' as const,
        section: 'provider' as const,
      },
      ...providerWithFallback,
    ];
  }

  async function loadAllSmartMovieSummaries(definition: NonNullable<ReturnType<typeof resolveSmartCategoryDefinition>>) {
    const smartCache = getSmartCategoryCacheSync(providerId, 'movie');
    const cached = getSmartCategoryEntrySync(providerId, 'movie', definition.key);
    const index = getMovieCatalogIndex(providerId);
    const catalogComplete = smartCache.catalogCompleteness?.catalogComplete !== false;

    if (cached?.itemIds.length && catalogComplete && definition.key !== 'new-releases' && definition.key !== 'discover') {
      return index.getSummaries(cached.itemIds);
    }

    const ctx = await buildLibraryContext(providerId);
    const maxItems = definition.maxItems ?? index.size;
    const result = querySmartCategoryOnIndex(index, definition, ctx, 0, maxItems) as {
      filtered: MovieCatalogEntry[];
      items: MovieCatalogEntry[];
      totalCount: number;
    };
    logSmartCategoryCatalogAudit({
      providerId,
      mediaType: 'movie',
      categoryKey: definition.key,
      candidateTotal: result.totalCount,
      catalogCompleteness: index.getCompleteness(),
    });
    return result.filtered.map(entryToSummary);
  }

  async function querySmartMovies(
    categoryId: string,
    offset: number,
    limit: number,
    sort: ContentSortOption = DEFAULT_CONTENT_SORT,
  ) {
    const definition = resolveSmartCategoryDefinition(categoryId);
    if (!definition) {
      return { items: [], totalCount: 0, hasMore: false, sortComplete: true, hasValidRatings: false };
    }

    const allItems = await loadAllSmartMovieSummaries(definition);
    const sorted = sortContentItems(allItems, sort, 'movie') as MovieSummary[];
    const page = paginateSortedItems(sorted, offset, limit);
    return {
      ...page,
      ...buildContentSortPageMetadata(allItems.length, sorted.length, categoryHasValidRatings(allItems)),
    };
  }

  return {
    async getCategories() {
      const providerCategories = await base.getCategories();
      return buildSmartCategories(providerCategories);
    },

    async getMoviesPage(input) {
      if (isSectionCategoryId(input.categoryId)) {
        return { items: [], totalCount: 0, hasMore: false };
      }

      if (isSmartCategoryId(input.categoryId)) {
        return querySmartMovies(input.categoryId, input.offset, input.limit, input.sort ?? DEFAULT_CONTENT_SORT);
      }

      return base.getMoviesPage(input);
    },

    async searchMovies(input) {
      return base.searchMovies(input);
    },

    getMovieInfo: base.getMovieInfo
      ? (movieId: string) => base.getMovieInfo!(movieId)
      : undefined,

    async getCategoryCount(categoryId) {
      if (isSectionCategoryId(categoryId)) {
        return 0;
      }

      if (isSmartCategoryId(categoryId)) {
        const definition = resolveSmartCategoryDefinition(categoryId);
        if (!definition) {
          return 0;
        }

        const count = getSmartCategoryCountSync(providerId, 'movie', definition.key);
        return definition.maxItems ? Math.min(count, definition.maxItems) : count;
      }

      return getCategoryCountFromIndex(providerId, 'movie', categoryId) ?? base.getCategoryCount?.(categoryId) ?? 0;
    },

    async prefetchAllCategoryCounts(categoryIds, onCategoryCount) {
      const providerIds = categoryIds.filter(isProviderCategoryId);
      if (!base.prefetchAllCategoryCounts) {
        return;
      }

      await base.prefetchAllCategoryCounts(providerIds, onCategoryCount);
    },

    async listCategoryMovies(categoryId) {
      if (!base.listCategoryMovies) {
        if (isProviderCategoryId(categoryId)) {
          const loaded = await loadAllMoviesForCatalogIndex(base, categoryId);
          return loaded.items;
        }
        return [];
      }

      return base.listCategoryMovies(categoryId);
    },
  };
}

export async function refreshSmartCategoryCounts(
  providerId: string,
  categories: MovieCategory[],
): Promise<MovieCategory[]> {
  const settings = await getMoviesSettings();
  if (settings.hideSmartCategories) {
    return categories;
  }

  const smartCache = getSmartCategoryCacheSync(providerId, 'movie');

  return categories.map((category) => {
    if (category.kind !== 'smart' || !category.smartKey) {
      if (category.kind === 'provider') {
        return {
          ...category,
          count: getCategoryCountFromIndex(providerId, 'movie', category.id) ?? category.count,
          countKnown: getCategoryCountFromIndex(providerId, 'movie', category.id) !== undefined || category.countKnown !== false,
        };
      }
      return category;
    }

    return {
      ...category,
      count: smartCache.entries[category.smartKey]?.count ?? category.count,
      countKnown: smartCache.entries[category.smartKey] !== undefined || category.countKnown !== false,
    };
  });
}

export function filterProviderCategoryIds(categories: MovieCategory[]) {
  return categories.filter((category) => category.kind === 'provider' || isProviderCategoryId(category.id)).map((category) => category.id);
}

export function findDefaultCategoryId(categories: MovieCategory[]) {
  const firstProvider = categories.find((category) => category.kind === 'provider');
  if (firstProvider) {
    return firstProvider.id;
  }

  const legacyProvider = categories.find(
    (category) => !isSmartCategoryId(category.id) && !isSectionCategoryId(category.id) && category.kind !== 'section',
  );
  if (legacyProvider) {
    return legacyProvider.id;
  }

  const firstSmart = categories.find((category) => category.kind === 'smart');
  if (firstSmart) {
    return firstSmart.id;
  }

  return categories.find((category) => !isSectionCategoryId(category.id))?.id ?? '';
}
