import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { ComponentProps, ElementRef } from 'react';
import { useEffect, useRef, useState } from 'react';
import { BackHandler, findNodeHandle, Platform, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import { getTvDensity } from '@/components/nova/tvDensity';
import { novaTheme } from '@/theme';

import { dismissNotification, triggerNotificationAction } from './notificationStore';
import { resolveNotificationInitialFocusTarget } from './notificationFocusLogic';
import type { AppNotification, AppNotificationType } from './types';

type IconName = ComponentProps<typeof MaterialCommunityIcons>['name'];
type Focusable = ElementRef<typeof Pressable>;

const TYPE_ICON: Record<AppNotificationType, IconName> = {
  error: 'alert-circle-outline',
  warning: 'alert-outline',
  success: 'check-circle-outline',
  info: 'information-outline',
};

const TYPE_ACCENT: Record<AppNotificationType, string> = {
  error: novaTheme.colors.danger,
  warning: novaTheme.colors.warning,
  success: novaTheme.colors.success,
  info: novaTheme.colors.accentHover,
};

type AppNotificationToastProps = {
  notification: AppNotification;
  captureFocus?: boolean;
};

/**
 * TV-safe toast card. When visible, focus is trapped inside the toast: it snaps to Dismiss
 * (or Retry when autoFocusAction is set), and D-pad navigation cannot escape to the screen
 * underneath until the toast is dismissed or its action is activated.
 */
export function AppNotificationToast({ notification, captureFocus = true }: AppNotificationToastProps) {
  const { width } = useWindowDimensions();
  const density = getTvDensity(width);
  const maxWidth = density === 'compact' ? 360 : 420;

  const actionRef = useRef<Focusable | null>(null);
  const dismissRef = useRef<Focusable | null>(null);
  const focusedButtonRef = useRef<'action' | 'dismiss' | null>(null);
  const lockDismissFocusRef = useRef(true);
  const [focusedButton, setFocusedButton] = useState<'action' | 'dismiss' | null>(null);
  const [actionHandle, setActionHandle] = useState<number | undefined>();
  const [dismissHandle, setDismissHandle] = useState<number | undefined>();

  const hasAction = Boolean(notification.actionLabel && notification.onAction);
  const initialFocusTarget = resolveNotificationInitialFocusTarget(
    notification.autoFocusAction ?? false,
    hasAction,
  );

  useEffect(() => {
    focusedButtonRef.current = focusedButton;
  }, [focusedButton]);

  useEffect(() => {
    lockDismissFocusRef.current = true;
  }, [notification.id]);

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      setActionHandle(findNodeHandle(actionRef.current) ?? undefined);
      setDismissHandle(findNodeHandle(dismissRef.current) ?? undefined);
    });
    return () => cancelAnimationFrame(frame);
  }, [hasAction]);

  useEffect(() => {
    if (!captureFocus || Platform.OS !== 'android') {
      return undefined;
    }

    const frame = requestAnimationFrame(() => {
      const target = initialFocusTarget === 'action' ? actionRef.current : dismissRef.current;
      target?.focus();
    });

    return () => cancelAnimationFrame(frame);
  }, [captureFocus, initialFocusTarget, notification.id]);

  useEffect(() => {
    if (Platform.OS !== 'android') {
      return undefined;
    }

    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!focusedButtonRef.current) {
        return false;
      }

      lockDismissFocusRef.current = false;
      dismissNotification(notification.id);
      return true;
    });

    return () => subscription.remove();
  }, [notification.id]);

  const releaseDismissFocusLock = () => {
    lockDismissFocusRef.current = false;
  };

  const restoreDismissFocusIfLocked = () => {
    if (!lockDismissFocusRef.current || initialFocusTarget !== 'dismiss') {
      return;
    }

    requestAnimationFrame(() => {
      dismissRef.current?.focus();
    });
  };

  const accentColor = TYPE_ACCENT[notification.type];
  const dismissTrapHandle = dismissHandle;
  const actionTrapHandle = actionHandle ?? dismissHandle;

  return (
    <View style={[styles.toast, { maxWidth, borderColor: `${accentColor}55` }]} importantForAccessibility="yes">
      <View style={styles.header}>
        <MaterialCommunityIcons name={TYPE_ICON[notification.type]} size={20} color={accentColor} />
        <Text style={styles.title} numberOfLines={1}>
          {notification.title}
        </Text>
      </View>

      {notification.message ? (
        <Text style={styles.message} numberOfLines={2}>
          {notification.message}
        </Text>
      ) : null}

      <View style={styles.actions}>
        {hasAction ? (
          <Pressable
            ref={actionRef}
            focusable
            hasTVPreferredFocus={captureFocus && initialFocusTarget === 'action'}
            accessibilityRole="button"
            accessibilityLabel={notification.actionLabel}
            {...(actionTrapHandle != null ? { nextFocusUp: actionTrapHandle, nextFocusDown: actionTrapHandle } : null)}
            {...(dismissHandle != null ? { nextFocusRight: dismissHandle } : null)}
            {...(actionTrapHandle != null ? { nextFocusLeft: actionTrapHandle } : null)}
            onFocus={() => {
              lockDismissFocusRef.current = false;
              setFocusedButton('action');
            }}
            onBlur={() => setFocusedButton((current) => (current === 'action' ? null : current))}
            onPress={() => {
              releaseDismissFocusLock();
              triggerNotificationAction(notification.id);
            }}
            style={[styles.actionButton, focusedButton === 'action' && styles.buttonFocused]}>
            <Text style={styles.actionText}>{notification.actionLabel}</Text>
          </Pressable>
        ) : null}

        <Pressable
          ref={dismissRef}
          focusable
          hasTVPreferredFocus={captureFocus && initialFocusTarget === 'dismiss'}
          accessibilityRole="button"
          accessibilityLabel={notification.dismissLabel ?? 'Dismiss'}
          {...(dismissTrapHandle != null
            ? {
                nextFocusUp: dismissTrapHandle,
                nextFocusDown: dismissTrapHandle,
                nextFocusRight: dismissTrapHandle,
              }
            : null)}
          {...(hasAction && actionHandle != null
            ? { nextFocusLeft: actionHandle }
            : dismissTrapHandle != null
              ? { nextFocusLeft: dismissTrapHandle }
              : null)}
          onFocus={() => setFocusedButton('dismiss')}
          onBlur={() => {
            setFocusedButton((current) => (current === 'dismiss' ? null : current));
            restoreDismissFocusIfLocked();
          }}
          onPress={() => {
            releaseDismissFocusLock();
            dismissNotification(notification.id);
          }}
          style={[styles.dismissButton, focusedButton === 'dismiss' && styles.buttonFocused]}>
          <MaterialCommunityIcons name="close" size={14} color={novaTheme.colors.textSecondary} />
          <Text style={styles.dismissText}>{notification.dismissLabel ?? 'Dismiss'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  toast: {
    minWidth: 300,
    borderRadius: novaTheme.radius.lg,
    borderWidth: 1,
    backgroundColor: 'rgba(11,15,22,0.94)',
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 8,
    shadowColor: '#000000',
    shadowOpacity: 0.4,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    flex: 1,
    minWidth: 0,
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '800',
  },
  message: {
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    lineHeight: 16,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
    marginTop: 2,
  },
  actionButton: {
    minHeight: 34,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: novaTheme.colors.surfaceMuted,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 12,
    fontWeight: '800',
  },
  dismissButton: {
    minHeight: 34,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 2,
    borderColor: 'transparent',
    paddingHorizontal: 10,
  },
  dismissText: {
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    fontWeight: '700',
  },
  buttonFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
});
