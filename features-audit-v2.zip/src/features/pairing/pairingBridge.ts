import { getSecureValue, pendingPairingKey, removeSecureValue, setSecureValue } from '../providers/providerCredentialStore.ts';

export type PairingConnectionPayload = {
  name: string;
  baseUrl: string;
  username: string;
  password: string;
};

/** Development credential injection is intentionally disabled; pairing must use the server flow. */
export function getDevPairingPayload(): PairingConnectionPayload | null {
  return null;
}

export async function savePendingPairingPayload(payload: PairingConnectionPayload) {
  await setSecureValue(pendingPairingKey(), JSON.stringify(payload));
}

export async function consumePendingPairingPayload() {
  const stored = await getSecureValue(pendingPairingKey());
  if (!stored) {
    return null;
  }

  try {
    const parsed = JSON.parse(stored) as PairingConnectionPayload;
    if (parsed?.baseUrl && parsed?.username && parsed?.password) {
      await removeSecureValue(pendingPairingKey());
      return parsed;
    }
  } catch {
    // Remove malformed secure state below.
  }

  await removeSecureValue(pendingPairingKey());
  return null;
}

export async function clearPendingPairingPayload() {
  await removeSecureValue(pendingPairingKey());
}
