import { getSecureValue, removeSecureValue, setSecureValue } from '../providers/providerCredentialStore.ts';

const INSTALLATION_ID_KEY = 'novacast.pairing.installation-id';
const PENDING_SESSION_KEY = 'novacast.pairing.pending-session';

export type PendingPairingSession = {
  id: string;
  code: string;
  pairUrl: string;
  expiresAt: number;
};

function isValidInstallationId(value: string | null): value is string {
  return Boolean(value && /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(value));
}

function createInstallationId() {
  const random = globalThis.crypto?.getRandomValues;
  if (!random) {
    throw new Error('Secure device identity generation is unavailable.');
  }

  const bytes = new Uint8Array(16);
  random.call(globalThis.crypto, bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export async function getPairingInstallationId() {
  const stored = await getSecureValue(INSTALLATION_ID_KEY);
  if (isValidInstallationId(stored)) {
    return stored;
  }

  const installationId = createInstallationId();
  await setSecureValue(INSTALLATION_ID_KEY, installationId);
  return installationId;
}

export async function getPendingPairingSession() {
  const stored = await getSecureValue(PENDING_SESSION_KEY);
  if (!stored) {
    return null;
  }

  try {
    const session = JSON.parse(stored) as PendingPairingSession;
    if (
      typeof session.id === 'string' &&
      typeof session.code === 'string' &&
      typeof session.pairUrl === 'string' &&
      Number.isFinite(session.expiresAt)
    ) {
      return session;
    }
  } catch {
    // Remove malformed local state below.
  }

  await clearPendingPairingSession();
  return null;
}

export function savePendingPairingSession(session: PendingPairingSession) {
  return setSecureValue(PENDING_SESSION_KEY, JSON.stringify(session));
}

export function clearPendingPairingSession() {
  return removeSecureValue(PENDING_SESSION_KEY);
}
