import type { PairingConnectionPayload } from './pairingBridge.ts';
import {
  clearPendingPairingSession,
  getPairingInstallationId,
  getPendingPairingSession,
  savePendingPairingSession,
  type PendingPairingSession,
} from './pairingDevice.ts';

export type PairingSession = PendingPairingSession;

export type PairingPollResult =
  | { status: 'waiting' }
  | { status: 'expired' }
  | { status: 'completed'; redemptionToken: string; providerName: string };

export interface PairingService {
  createSession(): Promise<PairingSession>;
  pollSession(sessionId: string): Promise<PairingPollResult>;
  redeemSession(sessionId: string, redemptionToken: string): Promise<PairingConnectionPayload>;
  cancelSession(sessionId: string): Promise<void>;
  regenerateSession(sessionId: string): Promise<PairingSession>;
}

type PairingApiResponse = {
  errorCategory?: string;
  error?: string;
  [key: string]: unknown;
};

let configuredPairingService: PairingService | null = null;
let remotePairingService: PairingService | null | undefined;

function getPairingApiConfig() {
  const apiUrl = process.env.EXPO_PUBLIC_NOVACAST_PAIRING_API_URL?.trim().replace(/\/+$/, '');
  const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY?.trim();
  if (!apiUrl || !anonKey) {
    return null;
  }

  return { apiUrl, anonKey };
}

function toPairingError(response: PairingApiResponse, fallback: string) {
  const category = typeof response.errorCategory === 'string' ? response.errorCategory : fallback;
  return new Error(category);
}

function normalizeSession(value: PairingApiResponse) {
  if (
    typeof value.sessionId !== 'string' ||
    typeof value.code !== 'string' ||
    typeof value.pairUrl !== 'string' ||
    typeof value.expiresAt !== 'number'
  ) {
    throw new Error('invalid_pairing_response');
  }

  return {
    id: value.sessionId,
    code: value.code,
    pairUrl: value.pairUrl,
    expiresAt: value.expiresAt,
  } satisfies PairingSession;
}

function createRemotePairingService(): PairingService | null {
  const config = getPairingApiConfig();
  if (!config) {
    return null;
  }

  async function request(path: string, body: Record<string, unknown>) {
    let response: Response;
    try {
      response = await fetch(`${config.apiUrl}/${path}`, {
        method: 'POST',
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${config.anonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
    } catch {
      throw new Error('pairing_service_unavailable');
    }

    let payload: PairingApiResponse = {};
    try {
      payload = (await response.json()) as PairingApiResponse;
    } catch {
      throw new Error('invalid_pairing_response');
    }

    if (!response.ok) {
      throw toPairingError(payload, 'pairing_request_failed');
    }

    return payload;
  }

  return {
    async createSession() {
      const pending = await getPendingPairingSession();
      if (pending && pending.expiresAt > Date.now()) {
        return pending;
      }

      const installationId = await getPairingInstallationId();
      const payload = await request('pairing-create', { installationId });
      const session = normalizeSession(payload);
      await savePendingPairingSession(session);
      return session;
    },

    async pollSession(sessionId) {
      const installationId = await getPairingInstallationId();
      const payload = await request('pairing-status', { installationId, sessionId });
      if (payload.status === 'expired') {
        await clearPendingPairingSession();
        return { status: 'expired' };
      }

      if (payload.status === 'completed' && typeof payload.redemptionToken === 'string' && typeof payload.providerName === 'string') {
        return {
          status: 'completed',
          redemptionToken: payload.redemptionToken,
          providerName: payload.providerName,
        };
      }

      return { status: 'waiting' };
    },

    async redeemSession(sessionId, redemptionToken) {
      const installationId = await getPairingInstallationId();
      const payload = await request('pairing-redeem', { installationId, sessionId, redemptionToken });
      if (
        typeof payload.providerName !== 'string' ||
        typeof payload.baseUrl !== 'string' ||
        typeof payload.username !== 'string' ||
        typeof payload.password !== 'string'
      ) {
        throw toPairingError(payload, 'invalid_pairing_response');
      }

      await clearPendingPairingSession();
      return {
        name: payload.providerName,
        baseUrl: payload.baseUrl,
        username: payload.username,
        password: payload.password,
      };
    },

    async cancelSession(sessionId) {
      const installationId = await getPairingInstallationId();
      await request('pairing-cancel', { installationId, sessionId });
      await clearPendingPairingSession();
    },

    async regenerateSession(sessionId) {
      await this.cancelSession(sessionId);
      return this.createSession();
    },
  } satisfies PairingService;
}

/** Returns the configured server service, or null when public pairing config is absent. */
export function getPairingService() {
  if (configuredPairingService) {
    return configuredPairingService;
  }

  if (remotePairingService === undefined) {
    remotePairingService = createRemotePairingService();
  }

  return remotePairingService;
}

export function setPairingServiceForTests(service: PairingService | null) {
  configuredPairingService = service;
}
