import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { markPairingCompleted, resetPairingCompleted } from '@/features/pairing/pairingState';
import { getPairingService, type PairingSession } from './pairingService';
import type { PairingConnectionPayload } from './pairingBridge';

type PairingStatus = 'unavailable' | 'waiting' | 'connected' | 'expired' | 'failed';

export function usePairing() {
  const service = getPairingService();
  const [status, setStatus] = useState<PairingStatus>(() => (service ? 'waiting' : 'unavailable'));
  const [session, setSession] = useState<PairingSession | null>(null);
  const [connectionPayload, setConnectionPayload] = useState<PairingConnectionPayload | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState(0);
  const [attempt, setAttempt] = useState(0);
  const redeemingRef = useRef(false);
  const pollingRef = useRef(false);

  useEffect(() => {
    if (!service) {
      setStatus('unavailable');
      return;
    }

    let cancelled = false;

    const createSession = async () => {
      try {
        const nextSession = await service.createSession();
        if (!cancelled) {
          setSession(nextSession);
          setStatus('waiting');
        }
      } catch {
        if (!cancelled) {
          setStatus('unavailable');
        }
      }
    };

    void createSession();
    return () => {
      cancelled = true;
    };
  }, [attempt, service]);

  useEffect(() => {
    if (!session || !service || status !== 'waiting') {
      return;
    }

    let cancelled = false;

    const poll = async () => {
      if (cancelled || pollingRef.current) {
        return;
      }

      pollingRef.current = true;
      try {
        const result = await service.pollSession(session.id);
        if (cancelled) {
          return;
        }

        if (result.status === 'expired') {
          setStatus('expired');
        } else if (result.status === 'completed' && !redeemingRef.current) {
          redeemingRef.current = true;
          setStatus('connected');
          try {
            const payload = await service.redeemSession(session.id, result.redemptionToken);
            if (!cancelled) {
              setConnectionPayload(payload);
              markPairingCompleted();
            }
          } catch {
            if (!cancelled) {
              setStatus('failed');
            }
          } finally {
            redeemingRef.current = false;
          }
        }
      } catch {
        if (!cancelled) {
          setStatus('unavailable');
        }
      } finally {
        pollingRef.current = false;
      }
    };

    const interval = setInterval(() => void poll(), 2_500);
    void poll();
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [service, session, status]);

  useEffect(() => {
    if (!session) {
      setSecondsRemaining(0);
      return;
    }

    const update = () => setSecondsRemaining(Math.max(0, Math.ceil((session.expiresAt - Date.now()) / 1000)));
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [session]);

  const regenerateCode = useCallback(() => {
    resetPairingCompleted();
    redeemingRef.current = false;
    setConnectionPayload(null);
    setSession(null);
    setStatus(service ? 'waiting' : 'unavailable');
    setAttempt((current) => current + 1);
  }, [service]);

  const countdownLabel = useMemo(() => {
    const minutes = Math.floor(secondsRemaining / 60).toString().padStart(2, '0');
    const seconds = (secondsRemaining % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  }, [secondsRemaining]);

  const statusText =
    status === 'unavailable'
      ? 'Pairing service unavailable. Check the pairing configuration and retry.'
      : status === 'connected'
        ? 'Provider verified. Connecting NovaCast...'
        : status === 'failed'
          ? 'The provider could not be added. Retry pairing.'
          : status === 'expired'
            ? 'Code expired. Generate a new code.'
            : 'Waiting for secure activation...';

  return {
    code: session?.code ?? null,
    shortUrl: session?.pairUrl ?? null,
    status,
    statusText,
    countdownLabel,
    regenerateCode,
    isAvailable: Boolean(service),
    connectionPayload,
  };
}

// Kept as a compatibility export for existing imports while the implementation is server-backed.
export const useMockPairing = usePairing;
