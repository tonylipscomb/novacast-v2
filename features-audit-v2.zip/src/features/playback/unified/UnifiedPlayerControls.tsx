import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { ComponentType, ElementRef, ReactNode } from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';
import * as ReactNative from 'react-native';
import {
  Animated,
  InteractionManager,
  findNodeHandle,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import { focusNativeViewWhenReady } from '@/features/navigation/focusNativeViewWhenReady';
import { displayStreamTitle } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

import {
  UNIFIED_CONTROL_ACTIVATE_DEBOUNCE_MS,
  resolveUnifiedControlFocusMove,
  resolveUnifiedSeekPosition,
  shouldAssignUnifiedPlayerInitialFocus,
  type UnifiedControlFocusId,
} from './unifiedPlayerLogic.ts';
import {
  isUnifiedRemoteDebugEnabled,
  logUnifiedRemoteEvent,
  setUnifiedRemoteFocusedControl,
} from './unifiedRemoteDebug.ts';

type UnifiedPlayerControlsProps = {
  title: string;
  subtitle?: string;
  visible: boolean;
  isPlaying: boolean;
  positionMs: number;
  durationMs: number;
  onTogglePlay: () => void;
  onRewind: () => void;
  onForward: () => void;
  onSeek: (nextPositionMs: number) => void;
  onBack: () => void;
  onReveal: () => void;
};

function formatTime(ms: number) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function resolveSeekDeltaFromNativeKeyEvent(nativeEvent: { key?: string; keyCode?: number | null }) {
  const key = nativeEvent.key ?? (nativeEvent.keyCode === 21 ? 'ArrowLeft' : nativeEvent.keyCode === 22 ? 'ArrowRight' : null);
  if (key === 'ArrowLeft') {
    return -10_000;
  }
  if (key === 'ArrowRight') {
    return 10_000;
  }
  return null;
}

function buildAndroidControlFocusProps(
  controlId: UnifiedControlFocusId,
  handles: Partial<Record<UnifiedControlFocusId, number>>,
) {
  const back = handles.back;
  const rewind = handles.rewind;
  const play = handles.play;
  const forward = handles.forward;
  const seek = handles.seek;

  switch (controlId) {
    case 'back':
      return seek != null ? { nextFocusDown: seek } : null;
    case 'rewind':
      return {
        ...(play != null ? { nextFocusRight: play } : {}),
        ...(seek != null ? { nextFocusUp: seek } : {}),
        ...(seek != null ? { nextFocusDown: seek } : {}),
      };
    case 'play':
      return {
        ...(rewind != null ? { nextFocusLeft: rewind } : {}),
        ...(forward != null ? { nextFocusRight: forward } : {}),
        ...(seek != null ? { nextFocusUp: seek } : {}),
        ...(seek != null ? { nextFocusDown: seek } : {}),
      };
    case 'forward':
      return {
        ...(play != null ? { nextFocusLeft: play } : {}),
        ...(seek != null ? { nextFocusUp: seek } : {}),
        ...(seek != null ? { nextFocusDown: seek } : {}),
      };
    case 'seek':
      return {
        ...(back != null ? { nextFocusUp: back } : {}),
        ...(rewind != null ? { nextFocusDown: rewind } : {}),
      };
    default:
      return null;
  }
}

export function UnifiedPlayerControls({
  title,
  subtitle,
  visible,
  isPlaying,
  positionMs,
  durationMs,
  onTogglePlay,
  onRewind,
  onForward,
  onSeek,
  onBack,
  onReveal,
}: UnifiedPlayerControlsProps) {
  const progress = durationMs > 0 ? Math.min(1, positionMs / durationMs) : 0;
  const elapsed = formatTime(positionMs);
  const remaining = formatTime(Math.max(0, durationMs - positionMs));
  const displayTitle = displayStreamTitle(title);
  const displaySubtitle = subtitle ? displayStreamTitle(subtitle) : undefined;
  const [opacity] = useState(() => new Animated.Value(visible ? 1 : 0));
  const reactNative = ReactNative as typeof ReactNative & {
    TVFocusGuideView?: typeof View;
  };
  const SeekFocusGuideView = (reactNative.TVFocusGuideView ?? View) as unknown as ComponentType<{
    children?: ReactNode;
    style?: unknown;
    trapFocusLeft?: boolean;
    trapFocusRight?: boolean;
  }>;
  const controlRefs = useRef<Record<UnifiedControlFocusId, ElementRef<typeof Pressable> | null>>({
    back: null,
    rewind: null,
    play: null,
    forward: null,
    seek: null,
  });
  const [androidFocusHandles, setAndroidFocusHandles] = useState<Partial<Record<UnifiedControlFocusId, number>>>({});
  const [focusedControl, setFocusedControl] = useState<UnifiedControlFocusId | null>(null);
  const [seekTargetMs, setSeekTargetMs] = useState<number | null>(null);
  const lastKeyActivateAtRef = useRef(0);
  const initialPlayerFocusAssignedRef = useRef(false);
  const seekTargetMsRef = useRef<number | null>(null);
  const activeSeekPositionMs = seekTargetMs ?? positionMs;
  const seekProgress = seekTargetMs != null && durationMs > 0 ? Math.min(1, activeSeekPositionMs / durationMs) : progress;
  const seekDisplayLabel = formatTime(activeSeekPositionMs);
  const durationLabel = formatTime(Math.max(0, durationMs));

  const handleControlFocus = useCallback(
    (controlId: UnifiedControlFocusId) => {
      setFocusedControl(controlId);
      setUnifiedRemoteFocusedControl(controlId);
      if (controlId === 'seek') {
        const initialTargetMs = positionMs;
        seekTargetMsRef.current = initialTargetMs;
        setSeekTargetMs(initialTargetMs);
      }
      if (isUnifiedRemoteDebugEnabled()) {
        logUnifiedRemoteEvent({
          source: 'controls-onFocus',
          eventType: 'focus',
          disposition: 'accepted',
          actionTaken: `focus-${controlId}`,
          controlId,
        });
      }
      onReveal();
    },
    [onReveal, positionMs],
  );

  const handleControlBlur = useCallback((controlId: UnifiedControlFocusId) => {
    setFocusedControl((current) => (current === controlId ? null : current));
    if (controlId === 'seek') {
      seekTargetMsRef.current = null;
      setSeekTargetMs(null);
    }
  }, []);

  const clampSeekPosition = useCallback(
    (nextPositionMs: number) => Math.max(0, Math.min(nextPositionMs, durationMs || nextPositionMs)),
    [durationMs],
  );

  const adjustSeekTarget = useCallback(
    (deltaMs: number) => {
      const baseMs = seekTargetMsRef.current ?? positionMs;
      const nextPositionMs = resolveUnifiedSeekPosition(baseMs, durationMs, deltaMs);
      if (nextPositionMs == null) {
        return;
      }
      seekTargetMsRef.current = nextPositionMs;
      setSeekTargetMs(nextPositionMs);
      if (isUnifiedRemoteDebugEnabled()) {
        logUnifiedRemoteEvent({
          source: 'controls-control-key',
          eventType: 'seek-adjust',
          disposition: 'accepted',
          actionTaken: `seek-adjust nextPositionMs=${nextPositionMs} deltaMs=${deltaMs}`,
          controlId: 'seek',
        });
      }
      onSeek(nextPositionMs);
    },
    [durationMs, onSeek, positionMs],
  );

  const focusControl = useCallback(
    (controlId: UnifiedControlFocusId) => {
      const target = controlRefs.current[controlId];
      if (!target) {
        return;
      }

      focusNativeViewWhenReady(
        () => controlRefs.current[controlId],
        () => {
          setUnifiedRemoteFocusedControl(controlId);
        },
      );
    },
    [],
  );

  const handleControlKeyDown = useCallback(
    (controlId: UnifiedControlFocusId) =>
      (event: {
        nativeEvent: { key?: string; keyCode?: number | null };
        preventDefault?: () => void;
        stopPropagation?: () => void;
      }) => {
        if (!visible || focusedControl !== controlId) {
          return;
        }

        if (controlId === 'seek') {
          const deltaMs = resolveSeekDeltaFromNativeKeyEvent(event.nativeEvent);
          if (deltaMs != null) {
            event.preventDefault?.();
            event.stopPropagation?.();
            adjustSeekTarget(deltaMs);
            return;
          }
        }

        const nextControl = resolveUnifiedControlFocusMove(controlId, event.nativeEvent);
        if (!nextControl || nextControl === controlId) {
          return;
        }

        event.preventDefault?.();
        event.stopPropagation?.();
        focusControl(nextControl);
      },
    [adjustSeekTarget, focusControl, focusedControl, visible],
  );

  const handleControlPress = useCallback(
    (controlId: UnifiedControlFocusId, actionTaken: string, handler: () => void) => {
      if (controlId !== 'back' && Date.now() - lastKeyActivateAtRef.current < UNIFIED_CONTROL_ACTIVATE_DEBOUNCE_MS) {
        return;
      }
      lastKeyActivateAtRef.current = Date.now();
      if (isUnifiedRemoteDebugEnabled()) {
        logUnifiedRemoteEvent({
          source: 'controls-onPress',
          eventType: 'press',
          disposition: 'accepted',
          actionTaken,
          controlId,
        });
      }
      handler();
    },
    [],
  );

  useEffect(() => {
    Animated.timing(opacity, {
      toValue: visible ? 1 : 0,
      duration: visible ? 180 : 500,
      useNativeDriver: true,
    }).start();
  }, [opacity, visible]);

  useEffect(() => {
    if (!shouldAssignUnifiedPlayerInitialFocus({
      visible,
      initialFocusAssigned: initialPlayerFocusAssignedRef.current,
      focusedControl,
    })) {
      return;
    }

    let cancelled = false;
    let focusCleanup: (() => void) | undefined;
    initialPlayerFocusAssignedRef.current = true;

    const task = InteractionManager.runAfterInteractions(() => {
      if (cancelled) {
        return;
      }

      if (isUnifiedRemoteDebugEnabled()) {
        logUnifiedRemoteEvent({
          source: 'controls-onFocus',
          eventType: 'focus',
          disposition: 'accepted',
          actionTaken: 'initial-player-focus-requested',
          controlId: 'play',
        });
      }

      focusCleanup = focusNativeViewWhenReady(
        () => controlRefs.current.play,
        () => {
          if (cancelled) {
            return;
          }
          setUnifiedRemoteFocusedControl('play');
        },
        8,
      );
    });

    return () => {
      cancelled = true;
      task.cancel();
      focusCleanup?.();
    };
  }, [visible, focusedControl]);

  const registerControlRef = useCallback(
    (controlId: UnifiedControlFocusId) => (instance: ElementRef<typeof Pressable> | null) => {
      controlRefs.current[controlId] = instance;

      if (Platform.OS !== 'android') {
        return;
      }

      const handle = instance ? findNodeHandle(instance) : null;
      setAndroidFocusHandles((current) => {
        const currentHandle = current[controlId];
        if ((handle == null && currentHandle == null) || currentHandle === handle) {
          return current;
        }

        const next = { ...current };
        if (handle == null) {
          delete next[controlId];
        } else {
          next[controlId] = handle;
        }
        return next;
      });
    },
    [],
  );

  const assignBackRef = registerControlRef('back');
  const assignRewindRef = registerControlRef('rewind');
  const assignPlayRef = registerControlRef('play');
  const assignForwardRef = registerControlRef('forward');
  const assignSeekRef = registerControlRef('seek');

  const backFocusProps = Platform.OS === 'android' ? buildAndroidControlFocusProps('back', androidFocusHandles) : null;
  const rewindFocusProps =
    Platform.OS === 'android' ? buildAndroidControlFocusProps('rewind', androidFocusHandles) : null;
  const playFocusProps = Platform.OS === 'android' ? buildAndroidControlFocusProps('play', androidFocusHandles) : null;
  const forwardFocusProps =
    Platform.OS === 'android' ? buildAndroidControlFocusProps('forward', androidFocusHandles) : null;
  const seekFocusProps = Platform.OS === 'android' ? buildAndroidControlFocusProps('seek', androidFocusHandles) : null;

  return (
    <View style={styles.host} pointerEvents="box-none">
      <Animated.View
        pointerEvents={visible ? 'auto' : 'none'}
        style={[styles.panelWrap, { opacity }]}>
        <View style={styles.panel}>
          <View style={styles.topBar}>
            <View style={styles.titles}>
              <Text numberOfLines={1} style={styles.title}>
                {displayTitle}
              </Text>
              {displaySubtitle ? (
                <Text numberOfLines={1} style={styles.subtitle}>
                  {displaySubtitle}
                </Text>
              ) : null}
            </View>
            <Pressable
              ref={assignBackRef}
              focusable={visible}
              accessibilityRole="button"
              accessibilityLabel="Player Back"
              {...(backFocusProps ?? {})}
              {...({ onKeyDown: handleControlKeyDown('back') } as any)}
              onPress={() => handleControlPress('back', 'back-close-playback', onBack)}
              onFocus={() => handleControlFocus('back')}
              onBlur={() => handleControlBlur('back')}
              style={[styles.backButton, focusedControl === 'back' && styles.focusedButton]}>
              <Text style={styles.backButtonText}>Back</Text>
            </Pressable>
          </View>

          <View style={styles.seekBlock}>
            <SeekFocusGuideView
              {...(Platform.OS === 'android' && reactNative.TVFocusGuideView ? { trapFocusLeft: true, trapFocusRight: true } : {})}
              style={styles.seekGuide}>
              <Pressable
                ref={assignSeekRef}
                focusable={visible}
                accessibilityRole="button"
                accessibilityLabel="Seek"
                {...(seekFocusProps ?? {})}
                {...({ onKeyDown: handleControlKeyDown('seek') } as any)}
                onPress={() => {
                  const commitTargetMs = seekTargetMsRef.current ?? activeSeekPositionMs;
                  const nextPositionMs = clampSeekPosition(commitTargetMs);
                  handleControlPress('seek', 'commit-seek', () => onSeek(nextPositionMs));
                  seekTargetMsRef.current = null;
                  setSeekTargetMs(null);
                }}
                onFocus={() => handleControlFocus('seek')}
                onBlur={() => handleControlBlur('seek')}
                style={[styles.seekCard, focusedControl === 'seek' && styles.seekCardFocused]}>
                <View style={styles.seekHeader}>
                  <Text style={styles.seekLabel}>Seek</Text>
                  <Text style={styles.seekValue}>
                    {seekTargetMs != null ? `Scrubbing to ${seekDisplayLabel}` : `${elapsed} / ${durationLabel}`}
                  </Text>
                </View>
                <View style={[styles.seekTrack, focusedControl === 'seek' && styles.seekTrackFocused]}>
                  <View style={[styles.seekFill, focusedControl === 'seek' && styles.seekFillFocused, { width: `${seekProgress * 100}%` }]} />
                  <View
                    style={[
                      styles.seekKnob,
                      focusedControl === 'seek' && styles.seekKnobFocused,
                      { left: `${Math.max(0, Math.min(100, (activeSeekPositionMs / Math.max(1, durationMs || activeSeekPositionMs)) * 100))}%` },
                    ]}
                  />
                </View>
                <View style={styles.timeRow}>
                  <Text style={styles.timeText}>
                    {seekTargetMs != null ? `Preview ${seekDisplayLabel}` : `Current ${elapsed}`}
                  </Text>
                  <Text style={styles.timeText}>{`Duration ${durationLabel} | Remaining ${remaining}`}</Text>
                </View>
                <Text style={[styles.seekHint, focusedControl === 'seek' && styles.seekHintFocused]}>
                  {seekTargetMs != null ? 'Left/Right scrub. OK commits.' : 'Focus and use Left/Right to scrub.'}
                </Text>
              </Pressable>
            </SeekFocusGuideView>
          </View>

          <View style={styles.controls}>
            <Pressable
              ref={assignRewindRef}
              focusable={visible}
              accessibilityRole="button"
              accessibilityLabel="Rewind"
              {...(rewindFocusProps ?? {})}
              {...({ onKeyDown: handleControlKeyDown('rewind') } as any)}
              onPress={() => handleControlPress('rewind', 'rewind-10s', onRewind)}
              onFocus={() => handleControlFocus('rewind')}
              onBlur={() => handleControlBlur('rewind')}
              style={[styles.controlButton, focusedControl === 'rewind' && styles.focusedButton]}>
              <MaterialCommunityIcons name="rewind" size={22} color={novaTheme.colors.textPrimary} />
              <Text style={styles.controlLabel}>Rewind 10s</Text>
            </Pressable>
            <Pressable
              ref={assignPlayRef}
              focusable={visible}
              accessibilityRole="button"
              accessibilityLabel={isPlaying ? 'Pause' : 'Play'}
              {...(playFocusProps ?? {})}
              {...({ onKeyDown: handleControlKeyDown('play') } as any)}
              onPress={() => handleControlPress('play', isPlaying ? 'pause-playback' : 'start-playback', onTogglePlay)}
              onFocus={() => handleControlFocus('play')}
              onBlur={() => handleControlBlur('play')}
              style={[
                styles.controlButton,
                styles.playButton,
                focusedControl === 'play' && styles.playButtonFocused,
              ]}>
              <MaterialCommunityIcons name={isPlaying ? 'pause' : 'play'} size={26} color="#FFFFFF" />
              <Text style={styles.playLabel}>{isPlaying ? 'Pause' : 'Play'}</Text>
            </Pressable>
            <Pressable
              ref={assignForwardRef}
              focusable={visible}
              accessibilityRole="button"
              accessibilityLabel="Fast Forward"
              {...(forwardFocusProps ?? {})}
              {...({ onKeyDown: handleControlKeyDown('forward') } as any)}
              onPress={() => handleControlPress('forward', 'forward-30s', onForward)}
              onFocus={() => handleControlFocus('forward')}
              onBlur={() => handleControlBlur('forward')}
              style={[styles.controlButton, focusedControl === 'forward' && styles.focusedButton]}>
              <MaterialCommunityIcons name="fast-forward" size={22} color={novaTheme.colors.textPrimary} />
              <Text style={styles.controlLabel}>Forward 30s</Text>
            </Pressable>
          </View>
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  host: {
    ...StyleSheet.absoluteFill,
    zIndex: 3,
    elevation: 8,
    justifyContent: 'flex-end',
  },
  panelWrap: {
    zIndex: 3,
    elevation: 8,
  },
  panel: {
    paddingHorizontal: 28,
    paddingBottom: 28,
    paddingTop: 18,
    backgroundColor: 'rgba(3,7,12,0.72)',
    gap: 14,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  titles: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  title: {
    color: novaTheme.colors.textPrimary,
    fontSize: 22,
    fontWeight: '800',
  },
  subtitle: {
    color: novaTheme.colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
  backButton: {
    minHeight: 44,
    borderRadius: novaTheme.radius.md,
    backgroundColor: 'rgba(18,24,34,0.88)',
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  backButtonText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '800',
  },
  seekBlock: {
    gap: 6,
  },
  seekGuide: {
    alignSelf: 'stretch',
  },
  seekCard: {
    borderRadius: novaTheme.radius.md,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 8,
  },
  seekCardFocused: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: 'rgba(23,30,42,0.96)',
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  seekHeader: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
  },
  seekLabel: {
    color: novaTheme.colors.textPrimary,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  seekValue: {
    color: novaTheme.colors.textSecondary,
    fontSize: 12,
    fontWeight: '700',
  },
  seekTrack: {
    position: 'relative',
    height: 5,
    borderRadius: 99,
    backgroundColor: 'rgba(255,255,255,0.18)',
    overflow: 'hidden',
  },
  seekTrackFocused: {
    backgroundColor: 'rgba(88, 124, 255, 0.32)',
  },
  seekFill: {
    height: '100%',
    borderRadius: 99,
    backgroundColor: novaTheme.colors.accent,
  },
  seekFillFocused: {
    backgroundColor: novaTheme.colors.focusRing,
  },
  seekKnob: {
    position: 'absolute',
    top: -4,
    width: 13,
    height: 13,
    marginLeft: -6.5,
    borderRadius: 6.5,
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: novaTheme.colors.accent,
  },
  seekKnobFocused: {
    width: 17,
    height: 17,
    top: -6,
    marginLeft: -8.5,
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.focusRing,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  timeText: {
    color: novaTheme.colors.textMuted,
    fontSize: 11,
    fontWeight: '700',
  },
  seekHint: {
    color: novaTheme.colors.textMuted,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  seekHintFocused: {
    color: novaTheme.colors.textSecondary,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: 14,
  },
  controlButton: {
    minWidth: 92,
    minHeight: 72,
    borderRadius: novaTheme.radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 2,
    borderColor: 'transparent',
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  controlLabel: {
    color: novaTheme.colors.textSecondary,
    fontSize: 11,
    fontWeight: '700',
    textAlign: 'center',
  },
  playButton: {
    minWidth: 104,
    minHeight: 78,
    backgroundColor: novaTheme.colors.accent,
  },
  playLabel: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '800',
    textAlign: 'center',
  },
  focusedButton: {
    borderColor: novaTheme.colors.focusRing,
    backgroundColor: novaTheme.colors.surfaceFocused,
  },
  playButtonFocused: {
    borderColor: novaTheme.colors.focusRing,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: novaTheme.glow.focusShadowOpacity,
    shadowRadius: novaTheme.glow.focusShadowRadius,
  },
});
