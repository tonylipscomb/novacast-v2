import { Pressable, StyleSheet, Text, View } from 'react-native';

import { novaTheme } from '@/theme';

import {
  isUnifiedRemoteDebugEnabled,
  logUnifiedRemoteEvent,
  setUnifiedRemoteFocusedControl,
} from './unifiedRemoteDebug.ts';

type UnifiedPlayerErrorStateProps = {
  message: string;
  onRetry: () => void;
  onBack: () => void;
};

export function UnifiedPlayerErrorState({ message, onRetry, onBack }: UnifiedPlayerErrorStateProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Playback issue</Text>
      <Text style={styles.message}>{message}</Text>
      <View style={styles.actions}>
        <Pressable
          focusable
          hasTVPreferredFocus
          onFocus={() => setUnifiedRemoteFocusedControl('error-retry')}
          onPress={() => {
            if (isUnifiedRemoteDebugEnabled()) {
              logUnifiedRemoteEvent({
                source: 'error-state-onPress',
                eventType: 'press',
                disposition: 'accepted',
                actionTaken: 'retry-playback',
                controlId: 'error-retry',
              });
            }
            onRetry();
          }}
          style={styles.primaryButton}>
          <Text style={styles.primaryText}>Retry</Text>
        </Pressable>
        <Pressable
          focusable
          onFocus={() => setUnifiedRemoteFocusedControl('error-back')}
          onPress={() => {
            if (isUnifiedRemoteDebugEnabled()) {
              logUnifiedRemoteEvent({
                source: 'error-state-onPress',
                eventType: 'press',
                disposition: 'accepted',
                actionTaken: 'close-playback',
                controlId: 'error-back',
              });
            }
            onBack();
          }}
          style={styles.secondaryButton}>
          <Text style={styles.secondaryText}>Back</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    paddingHorizontal: 32,
    backgroundColor: 'rgba(0,0,0,0.72)',
  },
  title: {
    color: novaTheme.colors.textPrimary,
    fontSize: 22,
    fontWeight: '800',
  },
  message: {
    color: novaTheme.colors.textSecondary,
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 20,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 8,
  },
  primaryButton: {
    minHeight: 44,
    borderRadius: novaTheme.radius.md,
    backgroundColor: novaTheme.colors.accent,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  secondaryButton: {
    minHeight: 44,
    borderRadius: novaTheme.radius.md,
    backgroundColor: 'rgba(18,24,34,0.88)',
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 14,
    fontWeight: '800',
  },
});
