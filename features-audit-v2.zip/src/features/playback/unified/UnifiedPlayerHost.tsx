import { StyleSheet, View } from 'react-native';

import { UnifiedPlayerController } from './UnifiedPlayerController.tsx';

/**
 * Single app-wide host for the unified native player.
 * Series and Live TV will launch through the same controller in later stages.
 */
export function UnifiedPlayerHost() {
  return (
    <View style={styles.host} pointerEvents="auto" focusable={false}>
      <UnifiedPlayerController />
    </View>
  );
}

const styles = StyleSheet.create({
  host: {
    ...StyleSheet.absoluteFill,
    zIndex: 200,
    elevation: 20,
  },
});
