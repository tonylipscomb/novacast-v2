import { useCallback, useRef } from 'react';
import { Pressable, StyleSheet } from 'react-native';

import { UNIFIED_CONTROL_ACTIVATE_DEBOUNCE_MS } from './unifiedPlayerLogic.ts';
import {
  isUnifiedRemoteDebugEnabled,
  logUnifiedRemoteEvent,
} from './unifiedRemoteDebug.ts';

type UnifiedPlayerInteractionLayerProps = {
  active: boolean;
  onTogglePlay: () => void;
};

export function UnifiedPlayerInteractionLayer({
  active,
  onTogglePlay,
}: UnifiedPlayerInteractionLayerProps) {
  const lastKeyActivateAtRef = useRef(0);

  const handlePress = useCallback(() => {
    if (Date.now() - lastKeyActivateAtRef.current < UNIFIED_CONTROL_ACTIVATE_DEBOUNCE_MS) {
      return;
    }
    lastKeyActivateAtRef.current = Date.now();
    if (isUnifiedRemoteDebugEnabled()) {
      logUnifiedRemoteEvent({
        source: 'controls-interaction-press',
        eventType: 'press',
        disposition: 'accepted',
        actionTaken: 'toggle-playback',
        controlId: 'interaction-layer',
      });
    }
    onTogglePlay();
  }, [onTogglePlay]);

  if (!active) {
    return null;
  }

  return (
    <Pressable
      focusable={false}
      pointerEvents="auto"
      onPress={handlePress}
      style={styles.layer}
      accessibilityLabel="Playback controls"
    />
  );
}

const styles = StyleSheet.create({
  layer: {
    ...StyleSheet.absoluteFill,
    zIndex: 10,
    elevation: 12,
  },
});
