import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { displayStreamTitle } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

type UnifiedPlayerLoadingStateProps = {
  title?: string;
};

export function UnifiedPlayerLoadingState({ title }: UnifiedPlayerLoadingStateProps) {
  const displayTitle = title ? displayStreamTitle(title) : undefined;

  return (
    <View style={styles.container}>
      <ActivityIndicator color={novaTheme.colors.accent} size="large" />
      <Text style={styles.title}>{displayTitle ? `Loading ${displayTitle}` : 'Loading playback'}</Text>
      <Text style={styles.copy}>Preparing your stream…</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFill,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  title: {
    color: novaTheme.colors.textPrimary,
    fontSize: 18,
    fontWeight: '800',
  },
  copy: {
    color: novaTheme.colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
});
