import { StyleSheet, useWindowDimensions, View } from 'react-native';

import { NovaStreamSurface } from '@/features/playback/NovaStreamPlayer';
import type { VideoPlayer } from 'expo-video';

import { UnifiedPlayerControls } from './UnifiedPlayerControls';
import { UnifiedPlayerInteractionLayer } from './UnifiedPlayerInteractionLayer';
import { UnifiedPlayerLoadingState } from './UnifiedPlayerLoadingState';
import type { UnifiedPlayerState } from './types.ts';
import { shouldShowUnifiedLoadingState } from './unifiedPlayerLogic.ts';

type UnifiedPlayerOverlayProps = {
  player: VideoPlayer;
  state: UnifiedPlayerState;
  onTogglePlay: () => void;
  onRewind: () => void;
  onForward: () => void;
  onSeek: (nextPositionMs: number) => void;
  onBack: () => void;
  onRevealControls: () => void;
};
export function UnifiedPlayerOverlay({
  player,
  state,
  onTogglePlay,
  onRewind,
  onForward,
  onSeek,
  onBack,
  onRevealControls,
}: UnifiedPlayerOverlayProps) {
  const { width, height } = useWindowDimensions();
  const showLoading = shouldShowUnifiedLoadingState(state.machineState);
  const captureRemoteInput = !state.controlsVisible;
  if (state.machineState === 'idle') {
    return null;
  }

  if (state.machineState === 'closing') {
    return (
      <View style={[styles.overlay, { width, height }]}>
        <View style={styles.closingCover} />
      </View>
    );
  }

  return (
    <View style={[styles.overlay, { width, height }]} accessibilityViewIsModal>
      <View style={styles.playerHost} focusable={false} importantForAccessibility="no-hide-descendants">
        <NovaStreamSurface
          player={player}
          style={styles.player}
          contentFit={state.contentFit}
        />
      </View>

      {showLoading ? <UnifiedPlayerLoadingState title={state.item?.title} /> : null}

      <UnifiedPlayerControls
        title={state.item?.title ?? 'Playback'}
        subtitle={state.item?.subtitle}
        visible={state.controlsVisible}
        isPlaying={state.isPlaying}
        positionMs={state.positionMs}
        durationMs={state.durationMs}
        onTogglePlay={onTogglePlay}
        onRewind={onRewind}
        onForward={onForward}
        onSeek={onSeek}
        onBack={onBack}
        onReveal={onRevealControls}
      />
      <UnifiedPlayerInteractionLayer
        active={captureRemoteInput}
        onTogglePlay={onTogglePlay}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: '#000000',
    zIndex: 100,
    elevation: 6,
  },
  playerHost: {
    ...StyleSheet.absoluteFill,
    zIndex: 1,
  },
  player: {
    ...StyleSheet.absoluteFill,
  },
  closingCover: {
    ...StyleSheet.absoluteFill,
    backgroundColor: '#000000',
    zIndex: 101,
  },
});
