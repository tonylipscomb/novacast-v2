import type { ProviderSearchHit } from '@/features/providers/providerRepositories';

export type SearchLoadStatus = 'idle' | 'loading' | 'ready' | 'empty' | 'error';

export const SEARCH_NOTIFICATION_ID = 'search-unavailable';
export const SEARCH_NOTIFICATION_DURATION_MS = 7000;
export const SEARCH_MIN_QUERY_LENGTH = 2;

export type SearchNotificationSpec = {
  title: string;
  message: string;
  persistent: boolean;
};

/** Only active search failures become toasts; idle/empty/loading stay inline. */
export function resolveSearchNotificationForStatus(
  status: SearchLoadStatus,
  retryAttemptedAndStillFailing: boolean,
  errorMessage?: string | null,
): SearchNotificationSpec | null {
  if (status !== 'error') {
    return null;
  }

  return {
    title: 'Search unavailable',
    message: errorMessage?.trim() || 'We could not search your provider library right now.',
    persistent: retryAttemptedAndStillFailing,
  };
}

export function searchHitKey(hit: ProviderSearchHit) {
  return `${hit.kind}:${hit.id}`;
}

export function searchHitKindLabel(kind: ProviderSearchHit['kind']) {
  if (kind === 'movie') {
    return 'Movie';
  }

  if (kind === 'series') {
    return 'Series';
  }

  return 'Live TV';
}
