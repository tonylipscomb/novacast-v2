/* eslint-disable react-hooks/set-state-in-effect -- Debounced provider search resets and applies async results in one effect. */
import { useCallback, useEffect, useRef, useState } from 'react';

import { useActiveProviderBundle } from '@/features/providers/useActiveProviderBundle';
import type { ProviderSearchHit } from '@/features/providers/providerRepositories';

import { SEARCH_MIN_QUERY_LENGTH, type SearchLoadStatus } from './searchScreenLogic';

const SEARCH_DEBOUNCE_MS = 350;

export function useSearchScreenModel() {
  const { bundle } = useActiveProviderBundle();
  const [query, setQueryState] = useState('');
  const [results, setResults] = useState<ProviderSearchHit[]>([]);
  const [status, setStatus] = useState<SearchLoadStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const requestIdRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const [reloadToken, setReloadToken] = useState(0);

  const reload = useCallback(() => {
    setReloadToken((current) => current + 1);
  }, []);

  const setQuery = useCallback((nextQuery: string) => {
    setQueryState(nextQuery);
  }, []);

  useEffect(() => {
    if (!bundle?.search) {
      return;
    }

    const trimmed = query.trim();
    if (trimmed.length < SEARCH_MIN_QUERY_LENGTH) {
      abortRef.current?.abort();
      abortRef.current = null;
      setResults([]);
      setErrorMessage(null);
      setStatus('idle');
      return;
    }

    const requestId = ++requestIdRef.current;
    const controller = new AbortController();
    abortRef.current?.abort();
    abortRef.current = controller;

    setStatus('loading');
    setErrorMessage(null);

    const timer = setTimeout(() => {
      void bundle.search
        .search(trimmed, controller.signal)
        .then((hits) => {
          if (requestId !== requestIdRef.current || controller.signal.aborted) {
            return;
          }

          setResults(hits);
          setStatus(hits.length > 0 ? 'ready' : 'empty');
        })
        .catch((error) => {
          if (requestId !== requestIdRef.current || controller.signal.aborted) {
            return;
          }

          setResults([]);
          setStatus('error');
          setErrorMessage(error instanceof Error ? error.message : 'Unable to search your provider library.');
        });
    }, SEARCH_DEBOUNCE_MS);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [bundle, query, reloadToken]);

  return {
    query,
    setQuery,
    results,
    status,
    errorMessage,
    reload,
    hasDataSource: Boolean(bundle?.search),
  };
}
