import type { ElementRef } from 'react';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { TvRemoteImage } from '@/components/media/TvRemoteImage';
import { MediaArtworkFallback } from '@/features/media-browser/MediaArtworkFallback';
import type { SeriesSummary } from '@/features/media-browser/mediaTypes';
import { displayStreamTitle, formatMediaMetaLabel } from '@/features/series/metadata/titleNormalization';
import { novaTheme } from '@/theme';

type SeriesPosterCardProps = {
  series: SeriesSummary;
  isSelected?: boolean;
  hasPreferredFocus?: boolean;
  onFocus: (series: SeriesSummary) => void;
  onPress?: (series: SeriesSummary) => void;
  registerRef?: (instance: ElementRef<typeof Pressable> | null) => void;
  isDiscover?: boolean;
};

export function SeriesPosterCard({
  series,
  isSelected = false,
  hasPreferredFocus,
  onFocus,
  onPress,
  registerRef,
  isDiscover = false,
}: SeriesPosterCardProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [failedPosterKey, setFailedPosterKey] = useState<string | null>(null);
  const posterKey = `${series.id}:${series.posterUrl ?? ''}`;
  const posterFailed = failedPosterKey === posterKey;
  const showPosterArt = Boolean(series.posterUrl) && !posterFailed;
  const metaPrimary = formatMediaMetaLabel({
    year: series.year,
    rating: series.rating,
    genre: series.genres[0],
  });

  return (
    <Pressable
      ref={registerRef}
      focusable
      hasTVPreferredFocus={hasPreferredFocus}
      onFocus={() => {
        setIsFocused(true);
        onFocus(series);
      }}
      onBlur={() => setIsFocused(false)}
      onPress={() => onPress?.(series)}
      style={[
        styles.card,
        isDiscover && styles.cardDiscover,
        isSelected && styles.cardSelected,
        isFocused && styles.cardFocused,
        isFocused && { borderColor: novaTheme.colors.focusRing },
      ]}>
      <View style={[styles.poster, isDiscover && styles.posterDiscover]}>
        {showPosterArt ? (
          <>
            <TvRemoteImage uri={series.posterUrl} style={styles.posterImage} onError={() => setFailedPosterKey(posterKey)} />
            {series.rating ? (
              <View style={styles.ratingBadge}>
                <MaterialCommunityIcons name="star" size={10} color="#F6C85F" />
                <Text style={styles.ratingText}>{series.rating}</Text>
              </View>
            ) : null}
          </>
        ) : (
          <MediaArtworkFallback title={series.title} kind="series" subtitle={series.year} compact />
        )}
      </View>

      <Text numberOfLines={1} style={styles.title}>
        {displayStreamTitle(series.title)}
      </Text>
      <View style={styles.metaRow}>
        {metaPrimary ? <Text style={styles.meta}>{metaPrimary}</Text> : null}
        {metaPrimary ? <View style={styles.metaDot} /> : null}
        <Text style={styles.meta}>{series.genres[0] ?? 'Series'}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 0,
    borderRadius: novaTheme.radius.md,
    borderWidth: 1,
    borderColor: 'transparent',
    padding: 4,
  },
  cardSelected: {
    borderColor: novaTheme.colors.accent,
    backgroundColor: 'rgba(59,130,246,0.05)',
  },
  cardFocused: {
    backgroundColor: 'rgba(59,130,246,0.08)',
    borderColor: novaTheme.colors.focusRing,
    shadowColor: novaTheme.colors.focusRing,
    shadowOpacity: 0.28,
    shadowRadius: 10,
  },
  poster: {
    aspectRatio: 2 / 3,
    borderRadius: novaTheme.radius.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
    backgroundColor: '#0B1018',
  },
  cardDiscover: {
    padding: 6,
  },
  posterDiscover: {
    aspectRatio: 16 / 10,
  },
  posterImage: {
    ...StyleSheet.absoluteFillObject,
  },
  ratingBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(5,9,15,0.78)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  ratingText: {
    color: novaTheme.colors.textPrimary,
    fontSize: 10,
    fontWeight: '800',
  },
  title: {
    marginTop: 6,
    color: novaTheme.colors.textPrimary,
    fontSize: 12,
    fontWeight: '700',
  },
  metaRow: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  meta: {
    color: novaTheme.colors.textMuted,
    fontSize: 10,
    fontWeight: '600',
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 99,
    backgroundColor: novaTheme.colors.textMuted,
  },
});
