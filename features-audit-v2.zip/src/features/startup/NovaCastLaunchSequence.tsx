import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Image, StyleSheet, Text, View, type LayoutChangeEvent } from 'react-native';

const PREPARING_MESSAGE = 'Preparing your library...';
const READY_MESSAGE = 'Launch ready';
const FINAL_LAUNCH_DURATION_MS = 600;

type LaunchStar = {
  left: `${number}%`;
  top: `${number}%`;
  size: number;
  distance: number;
  delay: number;
};

const STARS: LaunchStar[] = [
  { left: '8%', top: '18%', size: 2, distance: 72, delay: 0 },
  { left: '16%', top: '64%', size: 3, distance: 110, delay: 260 },
  { left: '26%', top: '27%', size: 2, distance: 84, delay: 480 },
  { left: '34%', top: '76%', size: 2, distance: 126, delay: 720 },
  { left: '48%', top: '14%', size: 2, distance: 94, delay: 120 },
  { left: '59%', top: '82%', size: 3, distance: 118, delay: 620 },
  { left: '68%', top: '24%', size: 2, distance: 82, delay: 340 },
  { left: '78%', top: '68%', size: 2, distance: 106, delay: 900 },
  { left: '88%', top: '34%', size: 3, distance: 130, delay: 540 },
  { left: '93%', top: '78%', size: 2, distance: 96, delay: 180 },
];

type NovaCastLaunchSequenceProps = {
  exitRequested: boolean;
  onExitComplete: () => void;
  onLayout: (event: LayoutChangeEvent) => void;
};

export function NovaCastLaunchSequence({ exitRequested, onExitComplete, onLayout }: NovaCastLaunchSequenceProps) {
  const [idleProgress] = useState(() => new Animated.Value(0));
  const [finalProgress] = useState(() => new Animated.Value(0));
  const [energyProgress] = useState(() => new Animated.Value(0));
  const [starProgress] = useState(() => STARS.map(() => new Animated.Value(0)));
  const idleAnimationsRef = useRef<Animated.CompositeAnimation[]>([]);
  const exitStartedRef = useRef(false);

  useEffect(() => {
    const idleDrift = Animated.loop(
      Animated.sequence([
        Animated.timing(idleProgress, {
          toValue: 1,
          duration: 4_800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(idleProgress, {
          toValue: 0,
          duration: 4_800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );

    const starAnimations = starProgress.map((progress, index) => {
      const star = STARS[index];
      return Animated.loop(
        Animated.sequence([
          Animated.delay(star.delay),
          Animated.timing(progress, {
            toValue: 1,
            duration: 1_350,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(progress, {
            toValue: 0,
            duration: 1_350,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ]),
      );
    });

    const animations = [idleDrift, ...starAnimations];
    idleAnimationsRef.current = animations;
    animations.forEach((animation) => animation.start());

    return () => {
      animations.forEach((animation) => animation.stop());
      idleAnimationsRef.current = [];
    };
  }, [idleProgress, starProgress]);

  useEffect(() => {
    if (!exitRequested || exitStartedRef.current) {
      return;
    }

    exitStartedRef.current = true;
    idleAnimationsRef.current.forEach((animation) => animation.stop());

    Animated.parallel([
      Animated.timing(finalProgress, {
        toValue: 1,
        duration: FINAL_LAUNCH_DURATION_MS,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(energyProgress, {
        toValue: 1,
        duration: FINAL_LAUNCH_DURATION_MS,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start(({ finished }) => {
      if (finished) {
        onExitComplete();
      }
    });
  }, [energyProgress, finalProgress, onExitComplete, exitRequested]);

  const backgroundScale = idleProgress.interpolate({ inputRange: [0, 1], outputRange: [1, 1.018] });
  const backgroundTranslateX = idleProgress.interpolate({ inputRange: [0, 1], outputRange: [0, 8] });
  const finalScale = finalProgress.interpolate({ inputRange: [0, 1], outputRange: [1, 1.06] });
  const finalTranslateX = finalProgress.interpolate({ inputRange: [0, 1], outputRange: [0, 24] });
  const finalOpacity = finalProgress.interpolate({ inputRange: [0, 0.72, 1], outputRange: [1, 0.9, 0] });
  const idleEnergyScale = idleProgress.interpolate({ inputRange: [0, 1], outputRange: [0.86, 1.14] });
  const energyScale = energyProgress.interpolate({ inputRange: [0, 1], outputRange: [1, 1.75] });
  const statusMessage = exitRequested ? READY_MESSAGE : PREPARING_MESSAGE;

  return (
    <View pointerEvents="none" style={styles.root} onLayout={onLayout} accessibilityElementsHidden>
      <Animated.View style={[styles.artwork, { opacity: finalOpacity, transform: [{ translateX: backgroundTranslateX }, { scale: backgroundScale }, { translateX: finalTranslateX }, { scale: finalScale }] }]}>
        <Image source={require('../../../splash.png')} style={styles.image} resizeMode="cover" />
      </Animated.View>

      <View style={styles.starField}>
        {STARS.map((star, index) => {
          const progress = starProgress[index];
          const translateX = progress.interpolate({ inputRange: [0, 1], outputRange: [0, star.distance] });
          const opacity = progress.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.2, 0.9, 0.15] });
          return (
            <Animated.View
              key={`${star.left}-${star.top}`}
              style={[styles.star, { left: star.left, top: star.top, width: star.size, height: star.size, opacity, transform: [{ translateX }] }]}
            />
          );
        })}
      </View>

      <Animated.View style={[styles.statusBlock, { opacity: finalOpacity }]}>
        <Text style={styles.statusText}>{statusMessage}</Text>
        <View style={styles.energyTrack}>
          <Animated.View style={[styles.energyLine, { transform: [{ scaleX: exitRequested ? energyScale : idleEnergyScale }] }]} />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#02030A',
    overflow: 'hidden',
  },
  artwork: {
    ...StyleSheet.absoluteFillObject,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  starField: {
    ...StyleSheet.absoluteFillObject,
  },
  star: {
    position: 'absolute',
    borderRadius: 99,
    backgroundColor: '#B9E8FF',
    shadowColor: '#2F8BFF',
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  statusBlock: {
    position: 'absolute',
    alignSelf: 'center',
    bottom: 64,
    width: '90%',
    maxWidth: 420,
    minHeight: 72,
    paddingHorizontal: 22,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(83, 151, 255, 0.45)',
    backgroundColor: 'rgba(3, 7, 22, 0.84)',
    shadowColor: '#1D70FF',
    shadowOpacity: 0.22,
    shadowRadius: 18,
    elevation: 8,
  },
  statusText: {
    color: '#F7FBFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  energyTrack: {
    width: 160,
    height: 2,
    marginTop: 12,
    overflow: 'hidden',
    borderRadius: 99,
    backgroundColor: 'rgba(95, 149, 216, 0.28)',
  },
  energyLine: {
    width: '100%',
    height: '100%',
    borderRadius: 99,
    backgroundColor: '#48A9FF',
  },
});
